% =============================================%
% Programed by Rustam Efendi, STTTelkom Bandung.
% efendi_rustam@yahoo.com
% Open for correction or any comments.
% =============================================%

function varargout = M_QAM(varargin)
global SNR_max jml_itr BR kanal rolloff M snr orde Alpha t Bit Split_Od ...
    Split_Ev Lsymbol_Od Lsymbol_Ev ttt LshapedI LshapedQ  Yinphase Yquadrat ...
    Yqam Yqamrx DemodI DemodQ LdetI LdetQ recLsymbolI recLsymbolQ ...
    rxdibitI rxtribitI rxfourbitI rxdibitQ rxtribitQ rxfourbitQ ...
    quadratosc inphaseosc recbit RayL rrcfilter fad1 nsamp Yqamj Yqamrxj ...
    LcompI LcompQ Lsymbolods Lsymbolevs bit_frame bit_frame_split bagi_waktu ...
    Bit_Masukan fs Lsymbolod Lsymbolev QQQ III rolloff

% Begin initialization code - DO NOT EDIT
gui_Singleton = 1;
gui_State = struct('gui_Name',       mfilename, ...
                   'gui_Singleton',  gui_Singleton, ...
                   'gui_OpeningFcn', @M_QAM_OpeningFcn, ...
                   'gui_OutputFcn',  @M_QAM_OutputFcn, ...
                   'gui_LayoutFcn',  [] , ...
                   'gui_Callback',   []);
if nargin && ischar(varargin{1})
    gui_State.gui_Callback = str2func(varargin{1});
end

if nargout
    [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
else
    gui_mainfcn(gui_State, varargin{:});
end
% End initialization code - DO NOT EDIT


% --- Executes just before M_QAM is made visible.
function M_QAM_OpeningFcn(hObject, eventdata, handles, varargin)
web www.wobishe.com
msgbox('����֧��Q609553134')
bg=imread('M_QAM.bmp');
axes(handles.axes1);
imshow(bg);

handles.output = hObject;
guidata(hObject, handles);


% --- Outputs from this function are returned to the command line.
function varargout = M_QAM_OutputFcn(hObject, eventdata, handles) 
% Get default command line output from handles structure
varargout{1} = handles.output;
atas(gcf)
clear all;


% --- popupmenu ---
function popupmenu1_Callback(hObject, eventdata, handles)
function popupmenu1_CreateFcn(hObject, eventdata, handles)
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
    msgbox('����֧��Q609553134')
end
function popupmenu2_Callback(hObject, eventdata, handles)
function popupmenu2_CreateFcn(hObject, eventdata, handles)
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end
function popupmenu3_Callback(hObject, eventdata, handles)
function popupmenu3_CreateFcn(hObject, eventdata, handles)
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end
function popupmenu4_Callback(hObject, eventdata, handles)
function popupmenu4_CreateFcn(hObject, eventdata, handles)
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end
function popupmenu5_Callback(hObject, eventdata, handles)
function popupmenu5_CreateFcn(hObject, eventdata, handles)
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end
function popupmenu6_Callback(hObject, eventdata, handles)
function popupmenu6_CreateFcn(hObject, eventdata, handles)
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

% --- edit ---
function edit1_Callback(hObject, eventdata, handles)
function edit1_CreateFcn(hObject, eventdata, handles)
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end
function edit2_Callback(hObject, eventdata, handles)
function edit2_CreateFcn(hObject, eventdata, handles)
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end
function edit3_Callback(hObject, eventdata, handles)
function edit3_CreateFcn(hObject, eventdata, handles)
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end
function edit4_Callback(hObject, eventdata, handles)
function edit4_CreateFcn(hObject, eventdata, handles)
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- pushbutton ---
function pushbutton1_Callback(hObject, eventdata, handles) % info
global t Bit bit_frame
if isempty(t)==1
    msgbox('Push "Submit" !');
else
[pos1 pos2]=posisi_grafik;
figure('Position',pos1) 
stairs(t,Bit), grid on; axis([0 bit_frame -0.1 1.1]); 
title('Input Bit'); xlabel('Time'); ylabel('Amplitude (V)')
figure('Position',pos2)
fs = length(Bit) - 1;
f_dom = fft(Bit);
f_dom = 20*log10(abs((f_dom(1:length(f_dom)/2+1))./(max(abs(f_dom))) + 1e-30));
ty = [0:length(f_dom)-1]*fs/length(f_dom)/2;
plot(ty,f_dom); grid on;
title('Input Bit');xlabel('Frequency'); ylabel('Normalized Power (dBw)')
end


function pushbutton2_Callback(hObject, eventdata, handles) % info I
global t Split_Od bit_frame
if isempty(t)==1
    msgbox('Push "Submit" !');
else
[pos1 pos2]=posisi_grafik;
figure('Position',pos1) 
stairs(t,Split_Od), grid on,axis([0 bit_frame -0.1 1.1]); 
title('Inphase Bit (Splitter Out)'); xlabel('Time'); ylabel('Amplitude (V)')
figure('Position',pos2) 
fs = length(Split_Od) - 1;
f_dom = fft(Split_Od);
f_dom = 20*log10(abs((f_dom(1:length(f_dom)/2+1))./(max(abs(f_dom))) + 1e-30));
ty = [0:length(f_dom)-1]*fs/length(f_dom)/2;
plot(ty,f_dom); grid on;
title('Inphase Bit (Splitter Out)');xlabel('Frequency'); ylabel('Normalized Power (dBw)')
end;


function pushbutton3_Callback(hObject, eventdata, handles) % info Q
global t Split_Ev bit_frame
if isempty(t)==1
    msgbox('Push "Submit" !');
else
[pos1 pos2]=posisi_grafik;
figure('Position',pos1)
stairs(t,Split_Ev), grid on,axis([0 bit_frame -0.1 1.1]); 
title('Quadrature Bit (Splitter Out)'); xlabel('Time)'); ylabel('Amplitude (V)')
figure('Position',pos2)
fs = length(Split_Ev) - 1;
f_dom = fft(Split_Ev);
f_dom = 20*log10(abs((f_dom(1:length(f_dom)/2+1))./(max(abs(f_dom))) + 1e-30));
ty = [0:length(f_dom)-1]*fs/length(f_dom)/2;
plot(ty,f_dom); grid on;
title('Quadrature Bit (Splitter Out)');xlabel('Frequency'); ylabel('Normalized Power (dBw)')
end;


function pushbutton4_Callback(hObject, eventdata, handles) % l conv I
global t Lsymbol_Od orde bit_frame
if isempty(t)==1
    msgbox('Push "Submit" !');
else
[pos1 pos2]=posisi_grafik;
if orde == 1
    X = 4;
elseif orde == 2
    X = 8;
elseif orde == 3
    X = 16;
end
figure('Position',pos1) 
stairs(t,Lsymbol_Od), grid on,axis([0 bit_frame -X X]); 
title('Multilevel Inphase Signal'); xlabel('Time'); ylabel('Amplitude (V)')
figure('Position',pos2) 
fs = length(Lsymbol_Od) - 1;
f_dom = fft(Lsymbol_Od);
f_dom = 20*log10(abs((f_dom(1:length(f_dom)/2+1))./(max(abs(f_dom))) + 1e-30));
ty = [0:length(f_dom)-1]*fs/length(f_dom)/2;
plot(ty,f_dom); grid on;
title('Multilevel Inphase Signal'); xlabel('Frequency'); ylabel('Normalized Power (dBw)')
end;


function pushbutton5_Callback(hObject, eventdata, handles) % l conv Q
global t Lsymbol_Ev orde bit_frame
if isempty(t)==1
    msgbox('Push "Submit" !');
else
[pos1 pos2]=posisi_grafik;
if orde == 1
    X = 4;
elseif orde == 2
    X = 8;
elseif orde == 3
    X = 16;
end
figure('Position',pos1) 
stairs(t,Lsymbol_Ev), grid on,axis([0 bit_frame -X X]); 
title('Multilevel Quadrature Signal'); xlabel('Time'); ylabel('Amplitude (V)')
figure('Position',pos2) 
fs = length(Lsymbol_Ev) - 1;
f_dom = fft(Lsymbol_Ev);
f_dom = 20*log10(abs((f_dom(1:length(f_dom)/2+1))./(max(abs(f_dom))) + 1e-30));
ty = [0:length(f_dom)-1]*fs/length(f_dom)/2;
plot(ty,f_dom); grid on;
title('Multilevel Quadrature Signal'); xlabel('Frequency'); ylabel('Normalized Power (dBw)')
end;


function pushbutton6_Callback(hObject, eventdata, handles) % cos
global ttt inphaseosc bit_frame fs
if isempty(ttt)==1
    msgbox('Push "Submit" !');
else
[pos1 pos2]=posisi_grafik;
figure('Position',pos1) 
plot(ttt(1:floor((length(ttt))./10)),inphaseosc(1:floor((length(ttt))./10))), grid on;
title('Carrier Signal of IF Quadrature Modulator'); xlabel('Time (s)'); ylabel('Amplitude (V)')
figure('Position',pos2) 
f_dom = fft(inphaseosc);
f_dom = 20*log10(abs((f_dom(1:length(f_dom)/2+1))./(max(abs(f_dom))) + 1e-30));
ty = [0:length(f_dom)-1]*fs/length(f_dom)/2;
plot(ty,f_dom); grid on;
title('Carrier Signal of IF Quadrature Modulator'); xlabel('Frequency (Hz)'); ylabel('Normalized Power (dBw)')
end;


function pushbutton7_Callback(hObject, eventdata, handles) % sin
global ttt quadratosc bit_frame fs
if isempty(ttt)==1
    msgbox('Push "Submit" !');
else
[pos1 pos2]=posisi_grafik;
figure('Position',pos1) 
plot(ttt(1:floor((length(ttt))./10)),quadratosc(1:floor((length(ttt))./10))), grid on;
title('Carrier Signal of IF Inphase Modulator'); xlabel('Time (s)'); ylabel('Amplitude (V)')
figure('Position',pos2) 
f_dom = fft(quadratosc);
f_dom = 20*log10(abs((f_dom(1:length(f_dom)/2+1))./(max(abs(f_dom))) + 1e-30));
ty = [0:length(f_dom)-1]*fs/length(f_dom)/2;
plot(ty,f_dom); grid on;
title('Carrier Signal of IF Inphase Modulator'); xlabel('Frequency (Hz)'); ylabel('Normalized Power (dBw)')
end;


function pushbutton8_Callback(hObject, eventdata, handles) % fil I
global t ttt LshapedI orde bit_frame bagi_waktu Bit_Masukan
if isempty(ttt)==1
    msgbox('Push "Submit" !');
else
[pos1 pos2]=posisi_grafik;
tt = ttt*Bit_Masukan;
figure('Position',pos1) 
plot(tt,LshapedI), grid on,axis([0 bit_frame min(LshapedI) max(LshapedI)]); %stairs
title('Multilevel Inphase Signal (Filter Out)'); xlabel('Time'); ylabel('Amplitude (V)')
figure('Position',pos2) 
fs = length(LshapedI) - 1;
f_dom = fft(LshapedI);
f_dom = 20*log10(abs((f_dom(1:length(f_dom)/2+1))./(max(abs(f_dom))) + 1e-30));
ty = [0:length(f_dom)-1]*fs/length(f_dom)/2;
plot(ty,f_dom); grid on;
title('Multilevel Inphase Signal (Filter Out)'); xlabel('Frequency');ylabel('Normalized Power (dBw)')
end;


function pushbutton9_Callback(hObject, eventdata, handles) % fil Q
global t ttt LshapedQ orde bit_frame bagi_waktu Bit_Masukan
if isempty(ttt)==1
    msgbox('Push "Submit" !');
else
[pos1 pos2]=posisi_grafik;
tt = ttt*Bit_Masukan;
figure('Position',pos1) 
plot(tt,LshapedQ), grid on,axis([0 bit_frame min(LshapedQ) max(LshapedQ)]); %stairs
title('Multilevel Quadrature Signal (Filter Out)'); xlabel('Time'); ylabel('Amplitude (V)')
figure('Position',pos2) 
fs = length(LshapedQ) - 1;
f_dom = fft(LshapedQ);
f_dom = 20*log10(abs((f_dom(1:length(f_dom)/2+1))./(max(abs(f_dom))) + 1e-30));
ty = [0:length(f_dom)-1]*fs/length(f_dom)/2;
plot(ty,f_dom); grid on;
title('Multilevel Quadrature Signal (Filter Out)'); xlabel('Frequency');ylabel('Normalized Power (dBw)')
end;


function pushbutton10_Callback(hObject, eventdata, handles) % mix I
global ttt Yinphase bit_frame bagi_waktu
if isempty(ttt)==1
    msgbox('Push "Submit" !');
else
[pos1 pos2]=posisi_grafik;
figure('Position',pos1) 
plot(ttt(1:floor((length(ttt))/bagi_waktu)),Yinphase(1:floor((length(ttt))/bagi_waktu))), grid on;
title('QAM Inphase Signal'); xlabel('Time (normalized)'); ylabel('Amplitude (V)')
figure('Position',pos2) 
fs = length(Yinphase) - 1;
f_dom = fft(Yinphase);
f_dom = 20*log10(abs((f_dom(1:length(f_dom)/2+1))./(max(abs(f_dom))) + 1e-30));
ty = [0:length(f_dom)-1]*fs/length(f_dom)/2;
plot(ty,f_dom); grid on;
title('QAM Inphase Signal'); xlabel('Frequency'); ylabel('Normalized Power (dBw)')
end;


function pushbutton11_Callback(hObject, eventdata, handles) % mix Q
global ttt Yquadrat bit_frame bagi_waktu
if isempty(ttt)==1
    msgbox('Push "Submit" !');
else
[pos1 pos2]=posisi_grafik;
figure('Position',pos1) 
plot(ttt(1:floor((length(ttt))/bagi_waktu)),Yquadrat(1:floor((length(ttt))/bagi_waktu))), grid on;
title('QAM Quadrature Signal'); xlabel('Time (normalized)'); ylabel('Amplitude (V)')
figure('Position',pos2) 
fs = length(Yquadrat) - 1;
f_dom = fft(Yquadrat);
f_dom = 20*log10(abs((f_dom(1:length(f_dom)/2+1))./(max(abs(f_dom))) + 1e-30));
ty = [0:length(f_dom)-1]*fs/length(f_dom)/2;
plot(ty,f_dom); grid on;
title('QAM Quadrature Signal'); xlabel('Frequency'); ylabel('Normalized Power (dBw)')
end;


function pushbutton12_Callback(hObject, eventdata, handles) % adder
global ttt Yqam bit_frame bagi_waktu
if isempty(ttt)==1
    msgbox('Push "Submit" !');
else
[pos1 pos2]=posisi_grafik;
figure('Position',pos1) 
plot(ttt(1:floor((length(ttt))/bagi_waktu)),Yqam(1:floor((length(ttt))/bagi_waktu))), grid on;
title('QAM Signal'); xlabel('Time (normalized)'); ylabel('Amplitude (V)')
figure('Position',pos2) 
fs = length(Yqam) - 1;
f_dom = fft(Yqam);
f_dom = 20*log10(abs((f_dom(1:length(f_dom)/2+1))./(max(abs(f_dom))) + 1e-30));
ty = [0:length(f_dom)-1]*fs/length(f_dom)/2;
plot(ty,f_dom); grid on;
title('QAM Signal'); xlabel('Frequency'); ylabel('Normalized Power (dBw)')
end;


function pushbutton13_Callback(hObject, eventdata, handles) % ray
global ttt kanal RayL bit_frame bagi_waktu
if isempty(ttt)==1
    msgbox('Push "Submit" !');
else
if kanal == 2
    [pos1 pos2]=posisi_grafik;
    figure('Position',pos1) 
    plot(ttt(1:floor((length(ttt))/bagi_waktu)),RayL(1:floor((length(ttt))/bagi_waktu))), grid on;
    title('QAM Signal at Rayleigh Channel'); xlabel('Time (normalized)'); ylabel('Amplitude (V)')
    figure('Position',pos2) 
    fs = length(RayL) - 1;
    f_dom = fft(RayL);
    f_dom = 20*log10(abs((f_dom(1:length(f_dom)/2+1))./(max(abs(f_dom))) + 1e-30));
    ty = [0:length(f_dom)-1]*fs/length(f_dom)/2;
    plot(ty,f_dom); grid on;
    title('QAM Signal at Rayleigh Channel'); xlabel('Frequency'); ylabel('Normalized Power (dBw)')
else
    msgbox('No picture, because selected channel is AWGN.');
end
end;


function pushbutton14_Callback(hObject, eventdata, handles) % awgn
global ttt Yqamrx kanal bit_frame bagi_waktu
if isempty(ttt)==1
    msgbox('Push "Submit" !');
else
if kanal == 1
    [pos1 pos2]=posisi_grafik;
    figure('Position',pos1) 
    plot(ttt(1:floor((length(ttt))/bagi_waktu)),Yqamrx(1:floor((length(ttt))/bagi_waktu))), grid on;
    title('Sinyal QAM Keluaran Kanal AWGN'); xlabel('Time (ternormalisasi terhadap jumlah simbol)'); ylabel('Amplitude (V)')
    figure('Position',pos2) 
    fs = length(Yqamrx) - 1;
    f_dom = fft(Yqamrx);
    f_dom = 20*log10(abs((f_dom(1:length(f_dom)/2+1))./(max(abs(f_dom))) + 1e-30));
    ty = [0:length(f_dom)-1]*fs/length(f_dom)/2;
    plot(ty,f_dom); grid on;
    title('Sinyal QAM Keluaran Kanal AWGN'); xlabel('Frequency'); ylabel('Normalized Power (dBw)')
else 
    [pos1 pos2]=posisi_grafik;
    figure('Position',pos1) 
    plot(ttt(1:floor((length(ttt))/bagi_waktu)),Yqamrx(1:floor((length(ttt))/bagi_waktu))), grid on;
    title('Sinyal QAM Keluaran Kanal Rayleigh + AWGN'); xlabel('Time (ternormalisasi terhadap jumlah simbol)'); ylabel('Amplitude (V)')
    figure('Position',pos2) 
    fs = length(Yqamrx) - 1;
    f_dom = fft(Yqamrx);
    f_dom = 20*log10(abs((f_dom(1:length(f_dom)/2+1))./(max(abs(f_dom))) + 1e-30));
    ty = [0:length(f_dom)-1]*fs/length(f_dom)/2;
    plot(ty,f_dom); grid on;
    title('Sinyal QAM Keluaran Kanal Rayleigh + AWGN'); xlabel('Frequency'); ylabel('Normalized Power (dBw)')
end
end;


function pushbutton15_Callback(hObject, eventdata, handles) % sin
global ttt quadratosc bit_frame fs
if isempty(ttt)==1
    msgbox('Push "Submit" !');
else
[pos1 pos2]=posisi_grafik;
figure('Position',pos1) 
plot(ttt(1:floor((length(ttt))./10)),quadratosc(1:floor((length(ttt))./10))), grid on;
title('Sinyal Carrier IF Inphase Demodulator'); xlabel('Time (s)'); ylabel('Amplitude (V)')
figure('Position',pos2) 
f_dom = fft(quadratosc);
f_dom = 20*log10(abs((f_dom(1:length(f_dom)/2+1))./(max(abs(f_dom))) + 1e-30));
ty = [0:length(f_dom)-1]*fs/length(f_dom)/2;
plot(ty,f_dom); grid on;
title('Sinyal Carrier IF Inphase Demodulator'); xlabel('Frequency (Hz)'); ylabel('Normalized Power (dBw)')
end;


function pushbutton16_Callback(hObject, eventdata, handles) % cos
global ttt inphaseosc bit_frame fs
if isempty(ttt)==1
    msgbox('Push "Submit" !');
else
[pos1 pos2]=posisi_grafik;
figure('Position',pos1) 
plot(ttt(1:floor((length(ttt))./10)),inphaseosc(1:floor((length(ttt))./10))), grid on;
title('Sinyal Carrier IF Quadrature Demodulator'); xlabel('Time (s)'); ylabel('Amplitude (V)')
figure('Position',pos2) 
f_dom = fft(inphaseosc);
f_dom = 20*log10(abs((f_dom(1:length(f_dom)/2+1))./(max(abs(f_dom))) + 1e-30));
ty = [0:length(f_dom)-1]*fs/length(f_dom)/2;
plot(ty,f_dom); grid on;
title('Sinyal Carrier IF Quadrature Demodulator'); xlabel('Frequency (Hz)'); ylabel('Normalized Power (dBw)')
end;


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


function pushbutton17_Callback(hObject, eventdata, handles) % mix I
global ttt DemodI orde bit_frame bagi_waktu Bit_Masukan
if isempty(ttt)==1
    msgbox('Push "Submit" !');
else
tt = ttt*Bit_Masukan;
[pos1 pos2]=posisi_grafik;
figure('Position',pos1) 
plot(tt,DemodI), grid on, axis([0 bit_frame min(DemodI) max(DemodI)]);
title('Inphase Signal (Mixing Output)'); xlabel('Time'); ylabel('Amplitude (V)')
figure('Position',pos2) 
fs = length(DemodI) - 1;
f_dom = fft(DemodI);
f_dom = 20*log10(abs((f_dom(1:length(f_dom)/2+1))./(max(abs(f_dom))) + 1e-30));
ty = [0:length(f_dom)-1]*fs/length(f_dom)/2;
plot(ty,f_dom); grid on;
title('Inphase Signal (Mixing Output)'); xlabel('Frequency'); ylabel('Frequency (dBw)')
end;


function pushbutton18_Callback(hObject, eventdata, handles) % mix Q
global ttt DemodQ orde bit_frame bagi_waktu Bit_Masukan
if isempty(ttt)==1
    msgbox('Push "Submit" !');
else
tt = ttt*Bit_Masukan;
[pos1 pos2]=posisi_grafik;
figure('Position',pos1) 
plot(tt,DemodQ), grid on, axis([0 bit_frame min(DemodQ) max(DemodQ)]);
title('Quadrature Signal (Mixing Output)'); xlabel('Time'); ylabel('Amplitude (V)')
figure('Position',pos2) 
fs = length(DemodQ) - 1;
f_dom = fft(DemodQ);
f_dom = 20*log10(abs((f_dom(1:length(f_dom)/2+1))./(max(abs(f_dom))) + 1e-30));
ty = [0:length(f_dom)-1]*fs/length(f_dom)/2;
plot(ty,f_dom); grid on;
title('Quadrature Signal (Mixing Output)'); xlabel('Frequency');ylabel('Frequency (dBw)')
end;


function pushbutton19_Callback(hObject, eventdata, handles) % fil I
global t ttt LdetI orde bit_frame bagi_waktu
if isempty(t)==1
    msgbox('Push "Submit" !');
else
[pos1 pos2]=posisi_grafik;
figure('Position',pos1) 
plot(t,LdetI), grid on, axis([0 bit_frame min(LdetI) max(LdetI)]);
title('Inphase Signal (Filter Output)'); xlabel('Time'); ylabel('Amplitude (V)')
figure('Position',pos2) 
fs = length(LdetI) - 1;
f_dom = fft(LdetI);
f_dom = 20*log10(abs((f_dom(1:length(f_dom)/2+1))./(max(abs(f_dom))) + 1e-30));
ty = [0:length(f_dom)-1]*fs/length(f_dom)/2;
plot(ty,f_dom); grid on;
title('Inphase Signal (Filter Output)'); xlabel('Frequency'); ylabel('Frequency (dBw)')
end;


function pushbutton20_Callback(hObject, eventdata, handles) % fil Q
global t ttt LdetQ orde bit_frame bagi_waktu
if isempty(t)==1
    msgbox('Push "Submit" !');
else
[pos1 pos2]=posisi_grafik;
figure('Position',pos1) 
plot(t,LdetQ), grid on, axis([0 bit_frame min(LdetQ) max(LdetQ)]);
title('Quadrature Signal (Filter Output)'); xlabel('Time'); ylabel('Amplitude (V)')
figure('Position',pos2) 
figure('Position',pos2) 
fs = length(LdetQ) - 1;
f_dom = fft(LdetQ);
f_dom = 20*log10(abs((f_dom(1:length(f_dom)/2+1))./(max(abs(f_dom))) + 1e-30));
ty = [0:length(f_dom)-1]*fs/length(f_dom)/2;
plot(ty,f_dom); grid on;
title('Quadrature Signal (Filter Output)'); xlabel('Frequency'); ylabel('Frequency (dBw)')
end;


function pushbutton21_Callback(hObject, eventdata, handles) % dec I
global t recLsymbolI orde bit_frame
if isempty(t)==1
    msgbox('Push "Submit" !');
else
[pos1 pos2]=posisi_grafik;
if orde == 1
    X = 4;
elseif orde == 2
    X = 8;
elseif orde == 3
    X = 16;
end
figure('Position',pos1) 
plot(t,recLsymbolI), grid on, axis([0 bit_frame -X X]);
title('Inphase Signal (Detector Output)'); xlabel('Time'); ylabel('Amplitude (V)')
figure('Position',pos2) 
fs = length(recLsymbolI) - 1;
f_dom = fft(recLsymbolI);
f_dom = 20*log10(abs((f_dom(1:length(f_dom)/2+1))./(max(abs(f_dom))) + 1e-30));
ty = [0:length(f_dom)-1]*fs/length(f_dom)/2;
plot(ty,f_dom); grid on;
title('Inphase Signal (Detector Output)'); xlabel('Frequency'); ylabel('Frequency (dBw)')
end;


function pushbutton22_Callback(hObject, eventdata, handles) % dec Q
global t recLsymbolQ orde bit_frame
if isempty(t)==1
    msgbox('Push "Submit" !');
else
[pos1 pos2]=posisi_grafik;
if orde == 1
    X = 4;
elseif orde == 2
    X = 8;
elseif orde == 3
    X = 16;
end
figure('Position',pos1) 
plot(t,recLsymbolQ), grid on, axis([0 bit_frame -X X]);
title('Quadrature Signal (Detector Output)'); xlabel('Time'); ylabel('Amplitude (V)')
figure('Position',pos2) 
fs = length(recLsymbolQ) - 1;
f_dom = fft(recLsymbolQ);
f_dom = 20*log10(abs((f_dom(1:length(f_dom)/2+1))./(max(abs(f_dom))) + 1e-30));
ty = [0:length(f_dom)-1]*fs/length(f_dom)/2;
plot(ty,f_dom); grid on;
title('Quadrature Signal (Detector Output)'); xlabel('Frequency'); ylabel('Frequency (dBw)')
end;


function pushbutton23_Callback(hObject, eventdata, handles) % l conv I
global t rxdibitI rxtribitI rxfourbitI orde bit_frame
if isempty(t)==1
    msgbox('Push "Submit" !');
else
[pos1 pos2]=posisi_grafik;
if orde == 1
    Y = rxdibitI;
elseif orde == 2
    Y = rxtribitI;
elseif orde == 3
    Y = rxfourbitI;
end
figure('Position',pos1) 
stairs(t,Y), grid on, axis([0 bit_frame -0.1 1.1]);
title('Inphase Signal (Level Converter Output)'); xlabel('Time'); ylabel('Amplitude (V)')
figure('Position',pos2) 
fs = length(Y) - 1;
f_dom = fft(Y);
f_dom = 20*log10(abs((f_dom(1:length(f_dom)/2+1))./(max(abs(f_dom))) + 1e-30));
ty = [0:length(f_dom)-1]*fs/length(f_dom)/2;
plot(ty,f_dom); grid on;
title('Inphase Signal (Level Converter Output)'); xlabel('Frequency'); ylabel('Frequency (dBw)')
end;


function pushbutton25_Callback(hObject, eventdata, handles) % l conv Q
global t rxdibitQ rxtribitQ rxfourbitQ orde bit_frame
if isempty(t)==1
    msgbox('Push "Submit" !');
else
[pos1 pos2]=posisi_grafik;
if orde == 1
    Z = rxdibitQ;
elseif orde == 2
    Z = rxtribitQ;
elseif orde == 3
    Z = rxfourbitQ;
end
figure('Position',pos1)
stairs(t,Z), grid on, axis([0 bit_frame -0.1 1.1]);
title('Quadrature Signal (Level Converter Output)'); xlabel('Time'); ylabel('Amplitude (V)')
figure('Position',pos2)
fs = length(Z) - 1;
f_dom = fft(Z);
f_dom = 20*log10(abs((f_dom(1:length(f_dom)/2+1))./(max(abs(f_dom))) + 1e-30));
ty = [0:length(f_dom)-1]*fs/length(f_dom)/2;
plot(ty,f_dom); grid on;
title('Quadrature Signal (Level Converter Output)'); xlabel('Frequency'); ylabel('Frequency (dBw)')
end;


function pushbutton26_Callback(hObject, eventdata, handles) % combiner
global t recbit bit_frame

if isempty(t)==1
    msgbox('Push "Submit" !');
else
[pos1 pos2]=posisi_grafik;
figure('Position',pos1) 
stairs(t,recbit), grid on, axis([0 bit_frame -0.1 1.1]); 
title('Data Out');xlabel('Time'); ylabel('Amplitude (V)')
figure('Position',pos2) 
fs = length(recbit) - 1;
f_dom = fft(recbit);
f_dom = 20*log10(abs((f_dom(1:length(f_dom)/2+1))./(max(abs(f_dom))) + 1e-30));
ty = [0:length(f_dom)-1]*fs/length(f_dom)/2;
plot(ty,f_dom); grid on;
title('Data Out');xlabel('Frequency'); ylabel('Frequency (dBw)')
end;


function pushbutton27_Callback(hObject, eventdata, handles) % restart
close all
M_QAM


function pushbutton28_Callback(hObject, eventdata, handles) % close
good_bye


function pushbutton29_Callback(hObject, eventdata, handles) % inputkan
global SNR_max jml_itr BR kanal rolloff M snr orde Alpha t Bit Split_Od ...
    Split_Ev Lsymbol_Od Lsymbol_Ev ttt LshapedI LshapedQ Yinphase Yquadrat ...
    Yqam Yqamrx DemodI DemodQ LdetI LdetQ recLsymbolI recLsymbolQ ...
    rxdibitI rxtribitI rxfourbitI rxdibitQ rxtribitQ rxfourbitQ ...
    quadratosc inphaseosc recbit RayL rrcfilter fad1 nsamp Yqamj Yqamrxj ...
    LcompI LcompQ Lsymbolods Lsymbolevs bit_frame bit_frame_split bagi_waktu ...
    Bit_Masukan fs  Lsymbolod Lsymbolev QQQ III rolloff

if get(handles.popupmenu1,'value')==1
elseif get(handles.popupmenu1,'value')==2
    BR = 1200;
elseif get(handles.popupmenu1,'value')==3
    BR = 9600;
elseif get(handles.popupmenu1,'value')==4
    BR = 19200;
end

if get(handles.popupmenu2,'value')==1
elseif get(handles.popupmenu2,'value')==2
    M = 16;
elseif get(handles.popupmenu2,'value')==3
    M = 64;
elseif get(handles.popupmenu2,'value')==4
    M = 256;
end

if get(handles.popupmenu3,'value')==1
elseif get(handles.popupmenu3,'value')==2
    rolloff = 0;
elseif get(handles.popupmenu3,'value')==3
    rolloff = 0.25;
elseif get(handles.popupmenu3,'value')==4
    rolloff = 0.5;
elseif get(handles.popupmenu3,'value')==5
    rolloff = 0.75;
elseif get(handles.popupmenu3,'value')==6
    rolloff = 1;
end

if get(handles.popupmenu4,'value')==1
elseif get(handles.popupmenu4,'value')==2
    kanal = 1;
elseif get(handles.popupmenu4,'value')==3
    kanal = 2;
end

if get(handles.popupmenu5,'value')==1
elseif get(handles.popupmenu5,'value')==2
    snr = 0;
elseif get(handles.popupmenu5,'value')==3
    snr = 5;
elseif get(handles.popupmenu5,'value')==4
    snr = 10;
elseif get(handles.popupmenu5,'value')==5
    snr = 15;
elseif get(handles.popupmenu5,'value')==6
    snr = 20;
elseif get(handles.popupmenu5,'value')==7
    snr = 25;
end


% =========================================================================
% =========================================================================
% =========================================================================
if  get(handles.popupmenu1,'value')==1 |...
    get(handles.popupmenu2,'value')==1 |...
    get(handles.popupmenu3,'value')==1 |...
    get(handles.popupmenu4,'value')==1 |...
    get(handles.popupmenu5,'value')==1
    msgbox('Unfilled Parameter !!!');
else

if BR == 1200
    bagi_waktu = 2;
elseif BR == 9600
    bagi_waktu = 4;
elseif BR == 19200
    bagi_waktu = 8;
end;

if     BR == 1200
    bit_frame = 25;
    bit_frame_split = 13 + 2;
elseif BR == 9600
    bit_frame = 195;
    bit_frame_split = 100 + 5;
elseif BR == 19200
    bit_frame = 385;
    bit_frame_split = 195 + 10;
end

if M == 16
    orde = 1;
elseif M == 64
    orde = 2;
elseif M == 256
    orde = 3;
end

Tb = 1/BR;     %perioda 1 bit
tau = 1.0e-6;
shift = round(tau/Tb);

Alpha = rolloff;
Bit_Masukan = BR*0.02;
Jumlah_Bit_Asli = Bit_Masukan;
if orde == 1
    Jumlah_Bit = floor(Jumlah_Bit_Asli/4)*4;
elseif orde == 2
    Jumlah_Bit = floor(Jumlah_Bit_Asli/6)*6;
elseif orde == 3
    Jumlah_Bit = floor(Jumlah_Bit_Asli/8)*8;
end

Bit_Asli            = randint(1,Jumlah_Bit);
tsampling   = 16;

% Mendapatkan A
for i = 1:tsampling
    A(i,:) = Bit_Asli;
end
A;
Bit      = reshape(A,1,length(Bit_Asli)*tsampling);

% Mendapatkan B
for i = 1:2*tsampling
    B(i,:) = Bit_Asli(1:2:length(Bit_Asli));
end
Split_Od = reshape(B,1,length(Bit_Asli)*tsampling);

% Mendapatkan C
for i = 1:2*tsampling
    C(i,:) = Bit_Asli(2:2:length(Bit_Asli));
end
Split_Ev = reshape(C,1,length(Bit_Asli)*tsampling);

t = linspace(0,length(Bit_Asli),length(Bit_Asli)*16);
splitod = Split_Od;
splitev = Split_Ev;
tbit = Jumlah_Bit;

%PARAMETERS
if orde == 1
	tdibit  = tbit/2;
	tsymbol = tbit/4;
elseif orde == 2
	ttribit = tbit/3;
	tsymbol = tbit/6;
elseif orde == 3
    tfourbit = tbit/4;
	tsymbol = tbit/8;
end

if orde == 1
	%DIBITS to 4 LEVEL SYMBOL CONVERTER
	%2-level dibit to 4-level symbol in Channel-I
	for i=1:2:tdibit
       if ((splitod(2*(i-1)*tsampling+1) == 1) & (splitod(2*i*tsampling+1) == 1))
          Lsymbolod((((i+1)/2)-1)*4*tsampling+1:((i+1)/2)*4*tsampling) = -3*ones(1,4*tsampling);
       end;
       if ((splitod(2*(i-1)*tsampling+1) == 1) & (splitod(2*i*tsampling+1) == 0))
          Lsymbolod((((i+1)/2)-1)*4*tsampling+1:((i+1)/2)*4*tsampling) = -1*ones(1,4*tsampling);
       end;
       if ((splitod(2*(i-1)*tsampling+1) == 0) & (splitod(2*i*tsampling+1) == 0))
          Lsymbolod((((i+1)/2)-1)*4*tsampling+1:((i+1)/2)*4*tsampling) =  1*ones(1,4*tsampling);
       end;
       if ((splitod(2*(i-1)*tsampling+1) == 0) & (splitod(2*i*tsampling+1) == 1))
          Lsymbolod((((i+1)/2)-1)*4*tsampling+1:((i+1)/2)*4*tsampling) =  3*ones(1,4*tsampling);
       end;
	end;
	clear i;
	%2-level dibit to 4-level symbol in Channel-Q
	for i=1:2:tdibit
       if ((splitev(2*(i-1)*tsampling+1) == 1) & (splitev(2*i*tsampling+1) == 1))
          Lsymbolev((((i+1)/2)-1)*4*tsampling+1:((i+1)/2)*4*tsampling) = -3*ones(1,4*tsampling);
       end;
       if ((splitev(2*(i-1)*tsampling+1) == 1) & (splitev(2*i*tsampling+1) == 0))
          Lsymbolev((((i+1)/2)-1)*4*tsampling+1:((i+1)/2)*4*tsampling) = -1*ones(1,4*tsampling);
       end;
       if ((splitev(2*(i-1)*tsampling+1) == 0) & (splitev(2*i*tsampling+1) == 0))
          Lsymbolev((((i+1)/2)-1)*4*tsampling+1:((i+1)/2)*4*tsampling) =  1*ones(1,4*tsampling);
       end;
       if ((splitev(2*(i-1)*tsampling+1) == 0) & (splitev(2*i*tsampling+1) == 1))
          Lsymbolev((((i+1)/2)-1)*4*tsampling+1:((i+1)/2)*4*tsampling) =  3*ones(1,4*tsampling);
       end;
	end;
	clear i;
elseif orde == 2
	%TRIBITS to 8 LEVEL SYMBOL CONVERTER
	%2-level tribit to 8-level symbol in Channel-I
	for i=1:3:(tbit/2)
       if ((splitod(2*(i-1)*tsampling+1) == 1) & (splitod(2*i*tsampling+1) == 1) & (splitod(2*(i+1)*tsampling+1) == 1))         
          Lsymbolod((((i+2)/3)-1)*6*tsampling+1:((i+2)/3)*6*tsampling) = -7*ones(1,6*tsampling);
       end;
       if ((splitod(2*(i-1)*tsampling+1) == 1) & (splitod(2*i*tsampling+1) == 1) & (splitod(2*(i+1)*tsampling+1) == 0))         
          Lsymbolod((((i+2)/3)-1)*6*tsampling+1:((i+2)/3)*6*tsampling) = -5*ones(1,6*tsampling);
       end;
       if ((splitod(2*(i-1)*tsampling+1) == 1) & (splitod(2*i*tsampling+1) == 0) & (splitod(2*(i+1)*tsampling+1) == 0))         
          Lsymbolod((((i+2)/3)-1)*6*tsampling+1:((i+2)/3)*6*tsampling) = -3*ones(1,6*tsampling);
       end;
       if ((splitod(2*(i-1)*tsampling+1) == 1) & (splitod(2*i*tsampling+1) == 0) & (splitod(2*(i+1)*tsampling+1) == 1))         
          Lsymbolod((((i+2)/3)-1)*6*tsampling+1:((i+2)/3)*6*tsampling) = -1*ones(1,6*tsampling);
       end;
       if ((splitod(2*(i-1)*tsampling+1) == 0) & (splitod(2*i*tsampling+1) == 0) & (splitod(2*(i+1)*tsampling+1) == 1))         
          Lsymbolod((((i+2)/3)-1)*6*tsampling+1:((i+2)/3)*6*tsampling) =  1*ones(1,6*tsampling);
       end;
       if ((splitod(2*(i-1)*tsampling+1) == 0) & (splitod(2*i*tsampling+1) == 0) & (splitod(2*(i+1)*tsampling+1) == 0)) 
          Lsymbolod((((i+2)/3)-1)*6*tsampling+1:((i+2)/3)*6*tsampling) =  3*ones(1,6*tsampling);
       end;
       if ((splitod(2*(i-1)*tsampling+1) == 0) & (splitod(2*i*tsampling+1) == 1) & (splitod(2*(i+1)*tsampling+1) == 0))         
          Lsymbolod((((i+2)/3)-1)*6*tsampling+1:((i+2)/3)*6*tsampling) =  5*ones(1,6*tsampling);
       end;
       if ((splitod(2*(i-1)*tsampling+1) == 0) & (splitod(2*i*tsampling+1) == 1) & (splitod(2*(i+1)*tsampling+1) == 1))         
          Lsymbolod((((i+2)/3)-1)*6*tsampling+1:((i+2)/3)*6*tsampling) =  7*ones(1,6*tsampling);
       end;
	end;
	clear i;
	%2-level tribit to 8-level symbol in Channel-Q
	for i=1:3:(tbit/2)
       if ((splitev(2*(i-1)*tsampling+1) == 1) & (splitev(2*i*tsampling+1) == 1) & (splitev(2*(i+1)*tsampling+1) == 1))         
          Lsymbolev((((i+2)/3)-1)*6*tsampling+1:((i+2)/3)*6*tsampling) = -7*ones(1,6*tsampling);
       end;
       if ((splitev(2*(i-1)*tsampling+1) == 1) & (splitev(2*i*tsampling+1) == 1) & (splitev(2*(i+1)*tsampling+1) == 0))       
          Lsymbolev((((i+2)/3)-1)*6*tsampling+1:((i+2)/3)*6*tsampling) = -5*ones(1,6*tsampling);
       end;
       if ((splitev(2*(i-1)*tsampling+1) == 1) & (splitev(2*i*tsampling+1) == 0) & (splitev(2*(i+1)*tsampling+1) == 0))         
          Lsymbolev((((i+2)/3)-1)*6*tsampling+1:((i+2)/3)*6*tsampling) = -3*ones(1,6*tsampling);
       end;
       if ((splitev(2*(i-1)*tsampling+1) == 1) & (splitev(2*i*tsampling+1) == 0) & (splitev(2*(i+1)*tsampling+1) == 1))         
          Lsymbolev((((i+2)/3)-1)*6*tsampling+1:((i+2)/3)*6*tsampling) = -1*ones(1,6*tsampling);
       end;
       if ((splitev(2*(i-1)*tsampling+1) == 0) & (splitev(2*i*tsampling+1) == 0) & (splitev(2*(i+1)*tsampling+1) == 1))         
          Lsymbolev((((i+2)/3)-1)*6*tsampling+1:((i+2)/3)*6*tsampling) =  1*ones(1,6*tsampling);
       end;
       if ((splitev(2*(i-1)*tsampling+1) == 0) & (splitev(2*i*tsampling+1) == 0) & (splitev(2*(i+1)*tsampling+1) == 0))         
          Lsymbolev((((i+2)/3)-1)*6*tsampling+1:((i+2)/3)*6*tsampling) =  3*ones(1,6*tsampling);
       end;
       if ((splitev(2*(i-1)*tsampling+1) == 0) & (splitev(2*i*tsampling+1) == 1) & (splitev(2*(i+1)*tsampling+1) == 0))     
          Lsymbolev((((i+2)/3)-1)*6*tsampling+1:((i+2)/3)*6*tsampling) =  5*ones(1,6*tsampling);
       end;
       if ((splitev(2*(i-1)*tsampling+1) == 0) & (splitev(2*i*tsampling+1) == 1) & (splitev(2*(i+1)*tsampling+1) == 1))         
          Lsymbolev((((i+2)/3)-1)*6*tsampling+1:((i+2)/3)*6*tsampling) =  7*ones(1,6*tsampling);
       end;
	end;
	clear i;
elseif orde == 3
    %fourbitS to 4 LEVEL SYMBOL CONVERTER
	%2-level fourbit to 4-level symbol in Channel-I
	for i=1:4:(tbit/2)
       if ((splitod(2*(i-1)*tsampling+1) == 1) & (splitod(2*i*tsampling+1) == 1) & (splitod(2*(i+1)*tsampling+1) == 1) & (splitod(2*(i+2)*tsampling+1) == 1)) 
          Lsymbolod((((i+3)/4)-1)*8*tsampling+1:((i+3)/4)*8*tsampling) = -15*ones(1,8*tsampling);
       end;
       if ((splitod(2*(i-1)*tsampling+1) == 1) & (splitod(2*i*tsampling+1) == 1) & (splitod(2*(i+1)*tsampling+1) == 1) & (splitod(2*(i+2)*tsampling+1) == 0))
          Lsymbolod((((i+3)/4)-1)*8*tsampling+1:((i+3)/4)*8*tsampling) = -13*ones(1,8*tsampling);
       end;
       if ((splitod(2*(i-1)*tsampling+1) == 1) & (splitod(2*i*tsampling+1) == 1) & (splitod(2*(i+1)*tsampling+1) == 0) & (splitod(2*(i+2)*tsampling+1) == 0))
          Lsymbolod((((i+3)/4)-1)*8*tsampling+1:((i+3)/4)*8*tsampling) = -11*ones(1,8*tsampling);
       end;
       if ((splitod(2*(i-1)*tsampling+1) == 1) & (splitod(2*i*tsampling+1) == 1) & (splitod(2*(i+1)*tsampling+1) == 0) & (splitod(2*(i+2)*tsampling+1) == 1))
          Lsymbolod((((i+3)/4)-1)*8*tsampling+1:((i+3)/4)*8*tsampling) = -9*ones(1,8*tsampling);
       end;
       if ((splitod(2*(i-1)*tsampling+1) == 1) & (splitod(2*i*tsampling+1) == 0) & (splitod(2*(i+1)*tsampling+1) == 0) & (splitod(2*(i+2)*tsampling+1) == 1))
          Lsymbolod((((i+3)/4)-1)*8*tsampling+1:((i+3)/4)*8*tsampling) = -7*ones(1,8*tsampling);
       end;
       if ((splitod(2*(i-1)*tsampling+1) == 1) & (splitod(2*i*tsampling+1) == 0) & (splitod(2*(i+1)*tsampling+1) == 0) & (splitod(2*(i+2)*tsampling+1) == 0))
          Lsymbolod((((i+3)/4)-1)*8*tsampling+1:((i+3)/4)*8*tsampling) = -5*ones(1,8*tsampling);
       end;
       if ((splitod(2*(i-1)*tsampling+1) == 1) & (splitod(2*i*tsampling+1) == 0) & (splitod(2*(i+1)*tsampling+1) == 1) & (splitod(2*(i+2)*tsampling+1) == 0))
          Lsymbolod((((i+3)/4)-1)*8*tsampling+1:((i+3)/4)*8*tsampling) = -3*ones(1,8*tsampling);
       end;
       if ((splitod(2*(i-1)*tsampling+1) == 1) & (splitod(2*i*tsampling+1) == 0) & (splitod(2*(i+1)*tsampling+1) == 1) & (splitod(2*(i+2)*tsampling+1) == 1))
          Lsymbolod((((i+3)/4)-1)*8*tsampling+1:((i+3)/4)*8*tsampling) = -1*ones(1,8*tsampling);
       end;
       if ((splitod(2*(i-1)*tsampling+1) == 0) & (splitod(2*i*tsampling+1) == 0) & (splitod(2*(i+1)*tsampling+1) == 1) & (splitod(2*(i+2)*tsampling+1) == 1)) 
          Lsymbolod((((i+3)/4)-1)*8*tsampling+1:((i+3)/4)*8*tsampling) =  1*ones(1,8*tsampling);
       end;
       if ((splitod(2*(i-1)*tsampling+1) == 0) & (splitod(2*i*tsampling+1) == 0) & (splitod(2*(i+1)*tsampling+1) == 1) & (splitod(2*(i+2)*tsampling+1) == 0))
          Lsymbolod((((i+3)/4)-1)*8*tsampling+1:((i+3)/4)*8*tsampling) =  3*ones(1,8*tsampling);
       end;
       if ((splitod(2*(i-1)*tsampling+1) == 0) & (splitod(2*i*tsampling+1) == 0) & (splitod(2*(i+1)*tsampling+1) == 0) & (splitod(2*(i+2)*tsampling+1) == 0))
          Lsymbolod((((i+3)/4)-1)*8*tsampling+1:((i+3)/4)*8*tsampling) =  5*ones(1,8*tsampling);
       end;
       if ((splitod(2*(i-1)*tsampling+1) == 0) & (splitod(2*i*tsampling+1) == 0) & (splitod(2*(i+1)*tsampling+1) == 0) & (splitod(2*(i+2)*tsampling+1) == 1))
          Lsymbolod((((i+3)/4)-1)*8*tsampling+1:((i+3)/4)*8*tsampling) =  7*ones(1,8*tsampling);
       end;
       if ((splitod(2*(i-1)*tsampling+1) == 0) & (splitod(2*i*tsampling+1) == 1) & (splitod(2*(i+1)*tsampling+1) == 0) & (splitod(2*(i+2)*tsampling+1) == 1))
          Lsymbolod((((i+3)/4)-1)*8*tsampling+1:((i+3)/4)*8*tsampling) =  9*ones(1,8*tsampling);
       end;
       if ((splitod(2*(i-1)*tsampling+1) == 0) & (splitod(2*i*tsampling+1) == 1) & (splitod(2*(i+1)*tsampling+1) == 0) & (splitod(2*(i+2)*tsampling+1) == 0))
          Lsymbolod((((i+3)/4)-1)*8*tsampling+1:((i+3)/4)*8*tsampling) = 11*ones(1,8*tsampling);
       end;
       if ((splitod(2*(i-1)*tsampling+1) == 0) & (splitod(2*i*tsampling+1) == 1) & (splitod(2*(i+1)*tsampling+1) == 1) & (splitod(2*(i+2)*tsampling+1) == 0))
          Lsymbolod((((i+3)/4)-1)*8*tsampling+1:((i+3)/4)*8*tsampling) = 13*ones(1,8*tsampling);
       end;
       if ((splitod(2*(i-1)*tsampling+1) == 0) & (splitod(2*i*tsampling+1) == 1) & (splitod(2*(i+1)*tsampling+1) == 1) & (splitod(2*(i+2)*tsampling+1) == 1))
          Lsymbolod((((i+3)/4)-1)*8*tsampling+1:((i+3)/4)*8*tsampling) = 15*ones(1,8*tsampling);
       end;
	end;
	clear i;
	%2-level fourbit to 4-level symbol in Channel-Q
	for i=1:4:(tbit/2)
       if ((splitev(2*(i-1)*tsampling+1) == 1) & (splitev(2*i*tsampling+1) == 1) & (splitev(2*(i+1)*tsampling+1) == 1) & (splitev(2*(i+2)*tsampling+1) == 1)) 
          Lsymbolev((((i+3)/4)-1)*8*tsampling+1:((i+3)/4)*8*tsampling) = -15*ones(1,8*tsampling);
       end;
       if ((splitev(2*(i-1)*tsampling+1) == 1) & (splitev(2*i*tsampling+1) == 1) & (splitev(2*(i+1)*tsampling+1) == 1) & (splitev(2*(i+2)*tsampling+1) == 0))
          Lsymbolev((((i+3)/4)-1)*8*tsampling+1:((i+3)/4)*8*tsampling) = -13*ones(1,8*tsampling);
       end;
       if ((splitev(2*(i-1)*tsampling+1) == 1) & (splitev(2*i*tsampling+1) == 1) & (splitev(2*(i+1)*tsampling+1) == 0) & (splitev(2*(i+2)*tsampling+1) == 0))
          Lsymbolev((((i+3)/4)-1)*8*tsampling+1:((i+3)/4)*8*tsampling) = -11*ones(1,8*tsampling);
       end;
       if ((splitev(2*(i-1)*tsampling+1) == 1) & (splitev(2*i*tsampling+1) == 1) & (splitev(2*(i+1)*tsampling+1) == 0) & (splitev(2*(i+2)*tsampling+1) == 1))
          Lsymbolev((((i+3)/4)-1)*8*tsampling+1:((i+3)/4)*8*tsampling) = -9*ones(1,8*tsampling);
       end;
       if ((splitev(2*(i-1)*tsampling+1) == 1) & (splitev(2*i*tsampling+1) == 0) & (splitev(2*(i+1)*tsampling+1) == 0) & (splitev(2*(i+2)*tsampling+1) == 1))
          Lsymbolev((((i+3)/4)-1)*8*tsampling+1:((i+3)/4)*8*tsampling) = -7*ones(1,8*tsampling);
       end;
       if ((splitev(2*(i-1)*tsampling+1) == 1) & (splitev(2*i*tsampling+1) == 0) & (splitev(2*(i+1)*tsampling+1) == 0) & (splitev(2*(i+2)*tsampling+1) == 0))
          Lsymbolev((((i+3)/4)-1)*8*tsampling+1:((i+3)/4)*8*tsampling) = -5*ones(1,8*tsampling);
       end;
       if ((splitev(2*(i-1)*tsampling+1) == 1) & (splitev(2*i*tsampling+1) == 0) & (splitev(2*(i+1)*tsampling+1) == 1) & (splitev(2*(i+2)*tsampling+1) == 0))
          Lsymbolev((((i+3)/4)-1)*8*tsampling+1:((i+3)/4)*8*tsampling) = -3*ones(1,8*tsampling);
       end;
       if ((splitev(2*(i-1)*tsampling+1) == 1) & (splitev(2*i*tsampling+1) == 0) & (splitev(2*(i+1)*tsampling+1) == 1) & (splitev(2*(i+2)*tsampling+1) == 1))
          Lsymbolev((((i+3)/4)-1)*8*tsampling+1:((i+3)/4)*8*tsampling) = -1*ones(1,8*tsampling);
       end;
       if ((splitev(2*(i-1)*tsampling+1) == 0) & (splitev(2*i*tsampling+1) == 0) & (splitev(2*(i+1)*tsampling+1) == 1) & (splitev(2*(i+2)*tsampling+1) == 1)) 
          Lsymbolev((((i+3)/4)-1)*8*tsampling+1:((i+3)/4)*8*tsampling) =  1*ones(1,8*tsampling);
       end;
       if ((splitev(2*(i-1)*tsampling+1) == 0) & (splitev(2*i*tsampling+1) == 0) & (splitev(2*(i+1)*tsampling+1) == 1) & (splitev(2*(i+2)*tsampling+1) == 0))
          Lsymbolev((((i+3)/4)-1)*8*tsampling+1:((i+3)/4)*8*tsampling) =  3*ones(1,8*tsampling);
       end;
       if ((splitev(2*(i-1)*tsampling+1) == 0) & (splitev(2*i*tsampling+1) == 0) & (splitev(2*(i+1)*tsampling+1) == 0) & (splitev(2*(i+2)*tsampling+1) == 0))
          Lsymbolev((((i+3)/4)-1)*8*tsampling+1:((i+3)/4)*8*tsampling) =  5*ones(1,8*tsampling);
       end;
       if ((splitev(2*(i-1)*tsampling+1) == 0) & (splitev(2*i*tsampling+1) == 0) & (splitev(2*(i+1)*tsampling+1) == 0) & (splitev(2*(i+2)*tsampling+1) == 1))
          Lsymbolev((((i+3)/4)-1)*8*tsampling+1:((i+3)/4)*8*tsampling) =  7*ones(1,8*tsampling);
       end;
       if ((splitev(2*(i-1)*tsampling+1) == 0) & (splitev(2*i*tsampling+1) == 1) & (splitev(2*(i+1)*tsampling+1) == 0) & (splitev(2*(i+2)*tsampling+1) == 1))
          Lsymbolev((((i+3)/4)-1)*8*tsampling+1:((i+3)/4)*8*tsampling) =  9*ones(1,8*tsampling);
       end;
       if ((splitev(2*(i-1)*tsampling+1) == 0) & (splitev(2*i*tsampling+1) == 1) & (splitev(2*(i+1)*tsampling+1) == 0) & (splitev(2*(i+2)*tsampling+1) == 0))
          Lsymbolev((((i+3)/4)-1)*8*tsampling+1:((i+3)/4)*8*tsampling) = 11*ones(1,8*tsampling);
       end;
       if ((splitev(2*(i-1)*tsampling+1) == 0) & (splitev(2*i*tsampling+1) == 1) & (splitev(2*(i+1)*tsampling+1) == 1) & (splitev(2*(i+2)*tsampling+1) == 0))
          Lsymbolev((((i+3)/4)-1)*8*tsampling+1:((i+3)/4)*8*tsampling) = 13*ones(1,8*tsampling);
       end;
       if ((splitev(2*(i-1)*tsampling+1) == 0) & (splitev(2*i*tsampling+1) == 1) & (splitev(2*(i+1)*tsampling+1) == 1) & (splitev(2*(i+2)*tsampling+1) == 1))
          Lsymbolev((((i+3)/4)-1)*8*tsampling+1:((i+3)/4)*8*tsampling) = 15*ones(1,8*tsampling);
       end;
	end;
    clear i;
end
Lsymbol_Od = Lsymbolod;
Lsymbol_Ev = Lsymbolev;

% Proses Filtering ========================================================
Lsymbolods = Lsymbol_Od.';
y = Lsymbolods;
nsamp = 4;
rolloff = Alpha;
filtorder = 40; % Filter order
delay = filtorder/(nsamp*2); % Group delay (# of input samples)
rrcfilter = rcosine(1,nsamp,'fir/sqrt',rolloff,delay); % Create a square root raised cosine filter. 'fir/sqrt'
ytx = rcosflt(y,1,nsamp,'filter',rrcfilter); % Upsample and apply square root raised cosine filter.
LshapedI = ytx.';

Lsymbolevs = Lsymbol_Ev.';
y = Lsymbolevs;
nsamp = 4;
rolloff = Alpha;
filtorder = 40; % Filter order
delay = filtorder/(nsamp*2); % Group delay (# of input samples)
rrcfilter = rcosine(1,nsamp,'fir/sqrt',rolloff,delay); % Create a square root raised cosine filter.
ytx = rcosflt(y,1,nsamp,'filter',rrcfilter); % Upsample and apply square root raised cosine filter.
LshapedQ = ytx.';

%PEMBANGKITAN FREKUENSI CARRIER
fc      = 100;
fs      = length(LshapedI)-1;
ttt = [0:(length(LshapedI)-1)]'./(length(LshapedI)-1);
inphaseosc = cos(2*pi*fc*ttt);
quadratosc = sin(2*pi*fc*ttt);
%INPHASE MODULATION
Yinphase = LshapedI.*inphaseosc.';
%QUADRATURE MODULATION
Yquadrat = LshapedQ.*quadratosc.';

Yqamj = LshapedI + LshapedQ.*j;
Yqam = Yinphase + Yquadrat;

% ==== Kanal ==============================================================
[Yqamrxj RayLj fad1j] = kanale(Yqamj,snr,kanal,shift);
[Yqamrx RayL fad1] = kanale(Yqam,snr,kanal,shift);
% Yqamrx = Yqam;
% ==== End of kanal =======================================================

if     orde == 1
    A = 2;
elseif orde == 2
    A = 3;
elseif orde == 3
    A = 4;
end
for i=1:1:tsymbol
   LshapedIc(i) = LshapedI(A*tsampling*(2*i-1));
   LshapedQc(i) = LshapedQ(A*tsampling*(2*i-1));
end;
    
% ==== Demod ==============================================================
DemodI = sqrt(2)*Yqamrx.*inphaseosc.';
DemodQ = sqrt(2)*Yqamrx.*quadratosc.';

% Filter received signal using square root raised cosine filter.
ytxI = DemodI.';
yrxI = rcosflt(ytxI,1,nsamp,'Fs/filter',rrcfilter);
yrxI = downsample(yrxI,nsamp); % Downsample.
yrxI = yrxI(2*delay+1:end-2*delay); % Account for delay.
LdetI = yrxI.';

% Filter received signal using square root raised cosine filter.
ytxQ = DemodQ.';
yrxQ = rcosflt(ytxQ,1,nsamp,'Fs/filter',rrcfilter);
yrxQ = downsample(yrxQ,nsamp); % Downsample.
yrxQ = yrxQ(2*delay+1:end-2*delay); % Account for delay.
LdetQ = yrxQ.';

if orde == 1
	%Decision-Circuit-I 4-level
	for i=1:1:tsymbol   
       LcompI(i) = LdetI(2*tsampling*(2*i-1));
       if (LcompI(i) >= 2) 
          recLsymbolI(((i-1)*4*tsampling+1):(i*4*tsampling)) =  3*ones(1,4*tsampling);
       end;
       if ((LcompI(i) >= 0) & (LcompI(i) < 2))
          recLsymbolI(((i-1)*4*tsampling+1):(i*4*tsampling)) =  1*ones(1,4*tsampling);
       end;
       if ((LcompI(i) >= -2) & (LcompI(i) < 0))
          recLsymbolI(((i-1)*4*tsampling+1):(i*4*tsampling)) = -1*ones(1,4*tsampling);
       end;
       if (LcompI(i) < -2) 
          recLsymbolI(((i-1)*4*tsampling+1):(i*4*tsampling)) = -3*ones(1,4*tsampling);
       end;
	end;
    %Decision-Circuit-Q 4-level
	for i=1:1:tsymbol   
       LcompQ(i) = LdetQ(2*tsampling*(2*i-1));
       if (LcompQ(i) >= 2) 
          recLsymbolQ(((i-1)*4*tsampling+1):(i*4*tsampling)) =  3*ones(1,4*tsampling);
       end;
       if ((LcompQ(i) >= 0) & (LcompQ(i) < 2))
          recLsymbolQ(((i-1)*4*tsampling+1):(i*4*tsampling)) =  1*ones(1,4*tsampling);
       end;
       if ((LcompQ(i) >= -2) & (LcompQ(i) < 0))
          recLsymbolQ(((i-1)*4*tsampling+1):(i*4*tsampling)) = -1*ones(1,4*tsampling);
       end;
       if (LcompQ(i) < -2) 
          recLsymbolQ(((i-1)*4*tsampling+1):(i*4*tsampling)) = -3*ones(1,4*tsampling);
       end;
	end;
    %4-level symbol to 2-level tribit in Channel-I
	for i=1:1:tsymbol
        III(i) = recLsymbolI(4*tsampling*(i-1)+1);
       if III(i) == -3
          rxdibitI((4*i-4)*tsampling+1:(4*i-2)*tsampling) = ones(1,2*tsampling);
          rxdibitI((4*i-2)*tsampling+1:(4*i-0)*tsampling) = ones(1,2*tsampling);
       end;
       if III(i) == -1
          rxdibitI((4*i-4)*tsampling+1:(4*i-2)*tsampling) = ones(1,2*tsampling);
          rxdibitI((4*i-2)*tsampling+1:(4*i-0)*tsampling) = zeros(1,2*tsampling);
       end;
       if III(i) == 1
          rxdibitI((4*i-4)*tsampling+1:(4*i-2)*tsampling) = zeros(1,2*tsampling);
          rxdibitI((4*i-2)*tsampling+1:(4*i-0)*tsampling) = zeros(1,2*tsampling);
       end;
       if III(i) == 3
          rxdibitI((4*i-4)*tsampling+1:(4*i-2)*tsampling) = zeros(1,2*tsampling);
          rxdibitI((4*i-2)*tsampling+1:(4*i-0)*tsampling) = ones(1,2*tsampling);
       end;
	end;
    clear i;
    %4-level symbol to 2-level tribit in Channel-Q
	for i=1:1:tsymbol
        QQQ(i) = recLsymbolQ(4*tsampling*(i-1)+1);
       if QQQ(i) == -3
          rxdibitQ((4*i-4)*tsampling+1:(4*i-2)*tsampling) = ones(1,2*tsampling);
          rxdibitQ((4*i-2)*tsampling+1:(4*i-0)*tsampling) = ones(1,2*tsampling);
       end;
       if QQQ(i) == -1
          rxdibitQ((4*i-4)*tsampling+1:(4*i-2)*tsampling) = ones(1,2*tsampling);
          rxdibitQ((4*i-2)*tsampling+1:(4*i-0)*tsampling) = zeros(1,2*tsampling);
       end;
       if QQQ(i) == 1
          rxdibitQ((4*i-4)*tsampling+1:(4*i-2)*tsampling) = zeros(1,2*tsampling);
          rxdibitQ((4*i-2)*tsampling+1:(4*i-0)*tsampling) = zeros(1,2*tsampling);
       end;
       if QQQ(i) == 3
          rxdibitQ((4*i-4)*tsampling+1:(4*i-2)*tsampling) = zeros(1,2*tsampling);
          rxdibitQ((4*i-2)*tsampling+1:(4*i-0)*tsampling) = ones(1,2*tsampling);
       end;
	end;
	clear i;
elseif orde == 2  
	%Decision-Circuit-I 8-level
	for i=1:1:tsymbol   
       LcompI(i) = LdetI(3*tsampling*(2*i-1));
       if (LcompI(i) < -6) 
          recLsymbolI(((i-1)*6*tsampling+1):(i*6*tsampling)) = -7*ones(1,6*tsampling);
       end;
       if ((LcompI(i) >= -6) & (LcompI(i) < -4))
          recLsymbolI(((i-1)*6*tsampling+1):(i*6*tsampling)) = -5*ones(1,6*tsampling);
       end;
       if ((LcompI(i) >= -4) & (LcompI(i) < -2))
          recLsymbolI(((i-1)*6*tsampling+1):(i*6*tsampling)) = -3*ones(1,6*tsampling);
       end;
       if ((LcompI(i) >= -2) & (LcompI(i) < 0))
          recLsymbolI(((i-1)*6*tsampling+1):(i*6*tsampling)) = -1*ones(1,6*tsampling);
       end;
       if ((LcompI(i) >= 0) & (LcompI(i) < 2))
          recLsymbolI(((i-1)*6*tsampling+1):(i*6*tsampling)) =  1*ones(1,6*tsampling);
       end;
       if ((LcompI(i) >= 2) & (LcompI(i) < 4))
          recLsymbolI(((i-1)*6*tsampling+1):(i*6*tsampling)) =  3*ones(1,6*tsampling);
       end;
       if ((LcompI(i) >= 4) & (LcompI(i) < 6))
          recLsymbolI(((i-1)*6*tsampling+1):(i*6*tsampling)) =  5*ones(1,6*tsampling);
       end;
       if ((LcompI(i) >= 6))
          recLsymbolI(((i-1)*6*tsampling+1):(i*6*tsampling)) =  7*ones(1,6*tsampling);
       end;
	end;
    %Decision-Circuit-Q 8-level
	for i=1:1:tsymbol   
       LcompQ(i) = LdetQ(3*tsampling*(2*i-1));
       if (LcompQ(i) < -6) 
          recLsymbolQ(((i-1)*6*tsampling+1):(i*6*tsampling)) = -7*ones(1,6*tsampling);
       end;
       if ((LcompQ(i) >= -6) & (LcompQ(i) < -4))
          recLsymbolQ(((i-1)*6*tsampling+1):(i*6*tsampling)) = -5*ones(1,6*tsampling);
       end;
       if ((LcompQ(i) >= -4) & (LcompQ(i) < -2))
          recLsymbolQ(((i-1)*6*tsampling+1):(i*6*tsampling)) = -3*ones(1,6*tsampling);
       end;
       if ((LcompQ(i) >= -2) & (LcompQ(i) < 0))
          recLsymbolQ(((i-1)*6*tsampling+1):(i*6*tsampling)) = -1*ones(1,6*tsampling);
       end;
       if ((LcompQ(i) >= 0) & (LcompQ(i) < 2))
          recLsymbolQ(((i-1)*6*tsampling+1):(i*6*tsampling)) =  1*ones(1,6*tsampling);
       end;
       if ((LcompQ(i) >= 2) & (LcompQ(i) < 4))
          recLsymbolQ(((i-1)*6*tsampling+1):(i*6*tsampling)) =  3*ones(1,6*tsampling);
       end;
       if ((LcompQ(i) >= 4) & (LcompQ(i) < 6))
          recLsymbolQ(((i-1)*6*tsampling+1):(i*6*tsampling)) =  5*ones(1,6*tsampling);
       end;
       if ((LcompQ(i) >= 6))
          recLsymbolQ(((i-1)*6*tsampling+1):(i*6*tsampling)) =  7*ones(1,6*tsampling);
       end;
	end;
	%8-level symbol to 2-level tribit in Channel-I
	for i=1:1:tsymbol
        III(i) = recLsymbolI(6*tsampling*(i-1)+1);
       if III(i) == -7
          rxtribitI((6*i-6)*tsampling+1:(6*i-4)*tsampling) = ones(1,2*tsampling);
          rxtribitI((6*i-4)*tsampling+1:(6*i-2)*tsampling) = ones(1,2*tsampling);
          rxtribitI((6*i-2)*tsampling+1:(6*i-0)*tsampling) = ones(1,2*tsampling);
       end;
       if III(i) == -5
          rxtribitI((6*i-6)*tsampling+1:(6*i-4)*tsampling) = ones(1,2*tsampling);
          rxtribitI((6*i-4)*tsampling+1:(6*i-2)*tsampling) = ones(1,2*tsampling);
          rxtribitI((6*i-2)*tsampling+1:(6*i-0)*tsampling) = zeros(1,2*tsampling);
       end;
       if III(i) == -3
          rxtribitI((6*i-6)*tsampling+1:(6*i-4)*tsampling) = ones(1,2*tsampling);
          rxtribitI((6*i-4)*tsampling+1:(6*i-2)*tsampling) = zeros(1,2*tsampling);
          rxtribitI((6*i-2)*tsampling+1:(6*i-0)*tsampling) = zeros(1,2*tsampling);
       end;
       if III(i) == -1
          rxtribitI((6*i-6)*tsampling+1:(6*i-4)*tsampling) = ones(1,2*tsampling);
          rxtribitI((6*i-4)*tsampling+1:(6*i-2)*tsampling) = zeros(1,2*tsampling);
          rxtribitI((6*i-2)*tsampling+1:(6*i-0)*tsampling) = ones(1,2*tsampling);
       end;
       if III(i) == 1
          rxtribitI((6*i-6)*tsampling+1:(6*i-4)*tsampling) = zeros(1,2*tsampling);
          rxtribitI((6*i-4)*tsampling+1:(6*i-2)*tsampling) = zeros(1,2*tsampling);
          rxtribitI((6*i-2)*tsampling+1:(6*i-0)*tsampling) = ones(1,2*tsampling);
       end;
       if III(i) == 3
          rxtribitI((6*i-6)*tsampling+1:(6*i-4)*tsampling) = zeros(1,2*tsampling);
          rxtribitI((6*i-4)*tsampling+1:(6*i-2)*tsampling) = zeros(1,2*tsampling);
          rxtribitI((6*i-2)*tsampling+1:(6*i-0)*tsampling) = zeros(1,2*tsampling);
       end;
       if III(i) == 5
          rxtribitI((6*i-6)*tsampling+1:(6*i-4)*tsampling) = zeros(1,2*tsampling);
          rxtribitI((6*i-4)*tsampling+1:(6*i-2)*tsampling) = ones(1,2*tsampling);
          rxtribitI((6*i-2)*tsampling+1:(6*i-0)*tsampling) = zeros(1,2*tsampling);
       end;
       if III(i) == 7
          rxtribitI((6*i-6)*tsampling+1:(6*i-4)*tsampling) = zeros(1,2*tsampling);
          rxtribitI((6*i-4)*tsampling+1:(6*i-2)*tsampling) = ones(1,2*tsampling);
          rxtribitI((6*i-2)*tsampling+1:(6*i-0)*tsampling) = ones(1,2*tsampling);
       end;
	end;
	clear i; 
    %8-level symbol to 2-level tribit in Channel-Q
	for i=1:1:tsymbol
        QQQ(i) = recLsymbolQ(6*tsampling*(i-1)+1);
       if QQQ(i) == -7
          rxtribitQ((6*i-6)*tsampling+1:(6*i-4)*tsampling) = ones(1,2*tsampling);
          rxtribitQ((6*i-4)*tsampling+1:(6*i-2)*tsampling) = ones(1,2*tsampling);
          rxtribitQ((6*i-2)*tsampling+1:(6*i-0)*tsampling) = ones(1,2*tsampling);
       end;
       if QQQ(i) == -5
          rxtribitQ((6*i-6)*tsampling+1:(6*i-4)*tsampling) = ones(1,2*tsampling);
          rxtribitQ((6*i-4)*tsampling+1:(6*i-2)*tsampling) = ones(1,2*tsampling);
          rxtribitQ((6*i-2)*tsampling+1:(6*i-0)*tsampling) = zeros(1,2*tsampling);
       end;
       if QQQ(i) == -3
          rxtribitQ((6*i-6)*tsampling+1:(6*i-4)*tsampling) = ones(1,2*tsampling);
          rxtribitQ((6*i-4)*tsampling+1:(6*i-2)*tsampling) = zeros(1,2*tsampling);
          rxtribitQ((6*i-2)*tsampling+1:(6*i-0)*tsampling) = zeros(1,2*tsampling);
       end;
       if QQQ(i) == -1
          rxtribitQ((6*i-6)*tsampling+1:(6*i-4)*tsampling) = ones(1,2*tsampling);
          rxtribitQ((6*i-4)*tsampling+1:(6*i-2)*tsampling) = zeros(1,2*tsampling);
          rxtribitQ((6*i-2)*tsampling+1:(6*i-0)*tsampling) = ones(1,2*tsampling);
       end;
       if QQQ(i) == 1
          rxtribitQ((6*i-6)*tsampling+1:(6*i-4)*tsampling) = zeros(1,2*tsampling);
          rxtribitQ((6*i-4)*tsampling+1:(6*i-2)*tsampling) = zeros(1,2*tsampling);
          rxtribitQ((6*i-2)*tsampling+1:(6*i-0)*tsampling) = ones(1,2*tsampling);
       end;
       if QQQ(i) == 3
          rxtribitQ((6*i-6)*tsampling+1:(6*i-4)*tsampling) = zeros(1,2*tsampling);
          rxtribitQ((6*i-4)*tsampling+1:(6*i-2)*tsampling) = zeros(1,2*tsampling);
          rxtribitQ((6*i-2)*tsampling+1:(6*i-0)*tsampling) = zeros(1,2*tsampling);
       end;
       if QQQ(i) == 5
          rxtribitQ((6*i-6)*tsampling+1:(6*i-4)*tsampling) = zeros(1,2*tsampling);
          rxtribitQ((6*i-4)*tsampling+1:(6*i-2)*tsampling) = ones(1,2*tsampling);
          rxtribitQ((6*i-2)*tsampling+1:(6*i-0)*tsampling) = zeros(1,2*tsampling);
       end;
       if QQQ(i) == 7
          rxtribitQ((6*i-6)*tsampling+1:(6*i-4)*tsampling) = zeros(1,2*tsampling);
          rxtribitQ((6*i-4)*tsampling+1:(6*i-2)*tsampling) = ones(1,2*tsampling);
          rxtribitQ((6*i-2)*tsampling+1:(6*i-0)*tsampling) = ones(1,2*tsampling);
       end;
	end;
	clear i; 
elseif orde == 3
	%Decision-Circuit-I 16-level
	for i=1:1:tsymbol   
       LcompI(i) = LdetI(4*tsampling*(2*i-1));
       if (LcompI(i) < -14) 
          recLsymbolI(((i-1)*8*tsampling+1):(i*8*tsampling)) = -15*ones(1,8*tsampling);
       end;
       if ((LcompI(i) >= -14) & (LcompI(i) < -12))
          recLsymbolI(((i-1)*8*tsampling+1):(i*8*tsampling)) = -13*ones(1,8*tsampling);
       end;
       if ((LcompI(i) >= -12) & (LcompI(i) < -10))
          recLsymbolI(((i-1)*8*tsampling+1):(i*8*tsampling)) = -11*ones(1,8*tsampling);
       end;
       if ((LcompI(i) >= -10) & (LcompI(i) < -8))
          recLsymbolI(((i-1)*8*tsampling+1):(i*8*tsampling)) =  -9*ones(1,8*tsampling);
       end;
       if ((LcompI(i) >= -8) & (LcompI(i) < -6))
          recLsymbolI(((i-1)*8*tsampling+1):(i*8*tsampling)) =  -7*ones(1,8*tsampling);
       end;
       if ((LcompI(i) >= -6) & (LcompI(i) < -4))
          recLsymbolI(((i-1)*8*tsampling+1):(i*8*tsampling)) =  -5*ones(1,8*tsampling);
       end;
       if ((LcompI(i) >= -4) & (LcompI(i) < -2))
          recLsymbolI(((i-1)*8*tsampling+1):(i*8*tsampling)) =  -3*ones(1,8*tsampling);
       end;
       if ((LcompI(i) >= -2) & (LcompI(i) < 0))
          recLsymbolI(((i-1)*8*tsampling+1):(i*8*tsampling)) =  -1*ones(1,8*tsampling);
       end;
       if ((LcompI(i) >= 0) & (LcompI(i) < 2)) 
          recLsymbolI(((i-1)*8*tsampling+1):(i*8*tsampling)) =   1*ones(1,8*tsampling);
       end;
       if ((LcompI(i) >= 2) & (LcompI(i) < 4))
          recLsymbolI(((i-1)*8*tsampling+1):(i*8*tsampling)) =   3*ones(1,8*tsampling);
       end;
       if ((LcompI(i) >= 4) & (LcompI(i) < 6))
          recLsymbolI(((i-1)*8*tsampling+1):(i*8*tsampling)) =   5*ones(1,8*tsampling);
       end;
       if ((LcompI(i) >= 6) & (LcompI(i) < 8))
          recLsymbolI(((i-1)*8*tsampling+1):(i*8*tsampling)) =   7*ones(1,8*tsampling);
       end;
       if ((LcompI(i) >= 8) & (LcompI(i) < 10))
          recLsymbolI(((i-1)*8*tsampling+1):(i*8*tsampling)) =   9*ones(1,8*tsampling);
       end;
       if ((LcompI(i) >= 10) & (LcompI(i) < 12))
          recLsymbolI(((i-1)*8*tsampling+1):(i*8*tsampling)) =  11*ones(1,8*tsampling);
       end;
       if ((LcompI(i) >= 12) & (LcompI(i) < 14))
          recLsymbolI(((i-1)*8*tsampling+1):(i*8*tsampling)) =  13*ones(1,8*tsampling);
       end;
       if ((LcompI(i) >= 14))
          recLsymbolI(((i-1)*8*tsampling+1):(i*8*tsampling)) =  15*ones(1,8*tsampling);
       end;
	end;
    %Decision-Circuit-Q 16-level
	for i=1:1:tsymbol   
       LcompQ(i) = LdetQ(4*tsampling*(2*i-1));
       if (LcompQ(i) < -14) 
          recLsymbolQ(((i-1)*8*tsampling+1):(i*8*tsampling)) = -15*ones(1,8*tsampling);
       end;
       if ((LcompQ(i) >= -14) & (LcompQ(i) < -12))
          recLsymbolQ(((i-1)*8*tsampling+1):(i*8*tsampling)) = -13*ones(1,8*tsampling);
       end;
       if ((LcompQ(i) >= -12) & (LcompQ(i) < -10))
          recLsymbolQ(((i-1)*8*tsampling+1):(i*8*tsampling)) = -11*ones(1,8*tsampling);
       end;
       if ((LcompQ(i) >= -10) & (LcompQ(i) < -8))
          recLsymbolQ(((i-1)*8*tsampling+1):(i*8*tsampling)) =  -9*ones(1,8*tsampling);
       end;
       if ((LcompQ(i) >= -8) & (LcompQ(i) < -6))
          recLsymbolQ(((i-1)*8*tsampling+1):(i*8*tsampling)) =  -7*ones(1,8*tsampling);
       end;
       if ((LcompQ(i) >= -6) & (LcompQ(i) < -4))
          recLsymbolQ(((i-1)*8*tsampling+1):(i*8*tsampling)) =  -5*ones(1,8*tsampling);
       end;
       if ((LcompQ(i) >= -4) & (LcompQ(i) < -2))
          recLsymbolQ(((i-1)*8*tsampling+1):(i*8*tsampling)) =  -3*ones(1,8*tsampling);
       end;
       if ((LcompQ(i) >= -2) & (LcompQ(i) < 0))
          recLsymbolQ(((i-1)*8*tsampling+1):(i*8*tsampling)) =  -1*ones(1,8*tsampling);
       end;
       if ((LcompQ(i) >= 0) & (LcompQ(i) < 2))
          recLsymbolQ(((i-1)*8*tsampling+1):(i*8*tsampling)) =   1*ones(1,8*tsampling);
       end;
       if ((LcompQ(i) >= 2) & (LcompQ(i) < 4))
          recLsymbolQ(((i-1)*8*tsampling+1):(i*8*tsampling)) =   3*ones(1,8*tsampling);
       end;
       if ((LcompQ(i) >= 4) & (LcompQ(i) < 6))
          recLsymbolQ(((i-1)*8*tsampling+1):(i*8*tsampling)) =   5*ones(1,8*tsampling);
       end;
       if ((LcompQ(i) >= 6) & (LcompQ(i) < 8))
          recLsymbolQ(((i-1)*8*tsampling+1):(i*8*tsampling)) =   7*ones(1,8*tsampling);
       end;
       if ((LcompQ(i) >= 8) & (LcompQ(i) < 10))
          recLsymbolQ(((i-1)*8*tsampling+1):(i*8*tsampling)) =   9*ones(1,8*tsampling);
       end;
       if ((LcompQ(i) >= 10) & (LcompQ(i) < 12))
          recLsymbolQ(((i-1)*8*tsampling+1):(i*8*tsampling)) =  11*ones(1,8*tsampling);
       end;
       if ((LcompQ(i) >= 12) & (LcompQ(i) < 14))
          recLsymbolQ(((i-1)*8*tsampling+1):(i*8*tsampling)) =  13*ones(1,8*tsampling);
       end;
       if ((LcompQ(i) >= 14))
          recLsymbolQ(((i-1)*8*tsampling+1):(i*8*tsampling)) =  15*ones(1,8*tsampling);
       end;
	end;
	%16-level symbol to 2-level fourbit in Channel-I
	for i=1:1:tsymbol
        III(i) = recLsymbolI(8*tsampling*(i-1)+1);
        if III(i) == -15
            rxfourbitI((8*i-8)*tsampling+1:(8*i-6)*tsampling) = ones(1,2*tsampling);
            rxfourbitI((8*i-6)*tsampling+1:(8*i-4)*tsampling) = ones(1,2*tsampling);
            rxfourbitI((8*i-4)*tsampling+1:(8*i-2)*tsampling) = ones(1,2*tsampling);
            rxfourbitI((8*i-2)*tsampling+1:(8*i-0)*tsampling) = ones(1,2*tsampling);
        end;
        if III(i) == -13
            rxfourbitI((8*i-8)*tsampling+1:(8*i-6)*tsampling) = ones(1,2*tsampling);
            rxfourbitI((8*i-6)*tsampling+1:(8*i-4)*tsampling) = ones(1,2*tsampling);
            rxfourbitI((8*i-4)*tsampling+1:(8*i-2)*tsampling) = ones(1,2*tsampling);
            rxfourbitI((8*i-2)*tsampling+1:(8*i-0)*tsampling) = zeros(1,2*tsampling);
        end;
        if III(i) == -11
            rxfourbitI((8*i-8)*tsampling+1:(8*i-6)*tsampling) = ones(1,2*tsampling);
            rxfourbitI((8*i-6)*tsampling+1:(8*i-4)*tsampling) = ones(1,2*tsampling);
            rxfourbitI((8*i-4)*tsampling+1:(8*i-2)*tsampling) = zeros(1,2*tsampling);
            rxfourbitI((8*i-2)*tsampling+1:(8*i-0)*tsampling) = zeros(1,2*tsampling);
        end;
        if III(i) == -9
            rxfourbitI((8*i-8)*tsampling+1:(8*i-6)*tsampling) = ones(1,2*tsampling);
            rxfourbitI((8*i-6)*tsampling+1:(8*i-4)*tsampling) = ones(1,2*tsampling);
            rxfourbitI((8*i-4)*tsampling+1:(8*i-2)*tsampling) = zeros(1,2*tsampling);
            rxfourbitI((8*i-2)*tsampling+1:(8*i-0)*tsampling) = ones(1,2*tsampling);
        end;
        if III(i) == -7
            rxfourbitI((8*i-8)*tsampling+1:(8*i-6)*tsampling) = ones(1,2*tsampling);
            rxfourbitI((8*i-6)*tsampling+1:(8*i-4)*tsampling) = zeros(1,2*tsampling);
            rxfourbitI((8*i-4)*tsampling+1:(8*i-2)*tsampling) = zeros(1,2*tsampling);
            rxfourbitI((8*i-2)*tsampling+1:(8*i-0)*tsampling) = ones(1,2*tsampling);
        end;
        if III(i) == -5
            rxfourbitI((8*i-8)*tsampling+1:(8*i-6)*tsampling) = ones(1,2*tsampling);
            rxfourbitI((8*i-6)*tsampling+1:(8*i-4)*tsampling) = zeros(1,2*tsampling);
            rxfourbitI((8*i-4)*tsampling+1:(8*i-2)*tsampling) = zeros(1,2*tsampling);
            rxfourbitI((8*i-2)*tsampling+1:(8*i-0)*tsampling) = zeros(1,2*tsampling);
        end;
        if III(i) == -3
            rxfourbitI((8*i-8)*tsampling+1:(8*i-6)*tsampling) = ones(1,2*tsampling);
            rxfourbitI((8*i-6)*tsampling+1:(8*i-4)*tsampling) = zeros(1,2*tsampling);
            rxfourbitI((8*i-4)*tsampling+1:(8*i-2)*tsampling) = ones(1,2*tsampling);
            rxfourbitI((8*i-2)*tsampling+1:(8*i-0)*tsampling) = zeros(1,2*tsampling);
        end;
        if III(i) == -1
            rxfourbitI((8*i-8)*tsampling+1:(8*i-6)*tsampling) = ones(1,2*tsampling);
            rxfourbitI((8*i-6)*tsampling+1:(8*i-4)*tsampling) = zeros(1,2*tsampling);
            rxfourbitI((8*i-4)*tsampling+1:(8*i-2)*tsampling) = ones(1,2*tsampling);
            rxfourbitI((8*i-2)*tsampling+1:(8*i-0)*tsampling) = ones(1,2*tsampling);
        end;
        if III(i) == 1
            rxfourbitI((8*i-8)*tsampling+1:(8*i-6)*tsampling) = zeros(1,2*tsampling);
            rxfourbitI((8*i-6)*tsampling+1:(8*i-4)*tsampling) = zeros(1,2*tsampling);
            rxfourbitI((8*i-4)*tsampling+1:(8*i-2)*tsampling) = ones(1,2*tsampling);
            rxfourbitI((8*i-2)*tsampling+1:(8*i-0)*tsampling) = ones(1,2*tsampling);
        end;
        if III(i) == 3
            rxfourbitI((8*i-8)*tsampling+1:(8*i-6)*tsampling) = zeros(1,2*tsampling);
            rxfourbitI((8*i-6)*tsampling+1:(8*i-4)*tsampling) = zeros(1,2*tsampling);
            rxfourbitI((8*i-4)*tsampling+1:(8*i-2)*tsampling) = ones(1,2*tsampling);
            rxfourbitI((8*i-2)*tsampling+1:(8*i-0)*tsampling) = zeros(1,2*tsampling);
        end;
        if III(i) == 5
            rxfourbitI((8*i-8)*tsampling+1:(8*i-6)*tsampling) = zeros(1,2*tsampling);
            rxfourbitI((8*i-6)*tsampling+1:(8*i-4)*tsampling) = zeros(1,2*tsampling);
            rxfourbitI((8*i-4)*tsampling+1:(8*i-2)*tsampling) = zeros(1,2*tsampling);
            rxfourbitI((8*i-2)*tsampling+1:(8*i-0)*tsampling) = zeros(1,2*tsampling);
        end;
        if III(i) == 7
            rxfourbitI((8*i-8)*tsampling+1:(8*i-6)*tsampling) = zeros(1,2*tsampling);
            rxfourbitI((8*i-6)*tsampling+1:(8*i-4)*tsampling) = zeros(1,2*tsampling);
            rxfourbitI((8*i-4)*tsampling+1:(8*i-2)*tsampling) = zeros(1,2*tsampling);
            rxfourbitI((8*i-2)*tsampling+1:(8*i-0)*tsampling) = ones(1,2*tsampling);
        end;
        if III(i) == 9
            rxfourbitI((8*i-8)*tsampling+1:(8*i-6)*tsampling) = zeros(1,2*tsampling);
            rxfourbitI((8*i-6)*tsampling+1:(8*i-4)*tsampling) = ones(1,2*tsampling);
            rxfourbitI((8*i-4)*tsampling+1:(8*i-2)*tsampling) = zeros(1,2*tsampling);
            rxfourbitI((8*i-2)*tsampling+1:(8*i-0)*tsampling) = ones(1,2*tsampling);
        end;
        if III(i) == 11
            rxfourbitI((8*i-8)*tsampling+1:(8*i-6)*tsampling) = zeros(1,2*tsampling);
            rxfourbitI((8*i-6)*tsampling+1:(8*i-4)*tsampling) = ones(1,2*tsampling);
            rxfourbitI((8*i-4)*tsampling+1:(8*i-2)*tsampling) = zeros(1,2*tsampling);
            rxfourbitI((8*i-2)*tsampling+1:(8*i-0)*tsampling) = zeros(1,2*tsampling);
        end;
        if III(i) == 13
            rxfourbitI((8*i-8)*tsampling+1:(8*i-6)*tsampling) = zeros(1,2*tsampling);
            rxfourbitI((8*i-6)*tsampling+1:(8*i-4)*tsampling) = ones(1,2*tsampling);
            rxfourbitI((8*i-4)*tsampling+1:(8*i-2)*tsampling) = ones(1,2*tsampling);
            rxfourbitI((8*i-2)*tsampling+1:(8*i-0)*tsampling) = zeros(1,2*tsampling);
        end;
        if III(i) == 15
            rxfourbitI((8*i-8)*tsampling+1:(8*i-6)*tsampling) = zeros(1,2*tsampling);
            rxfourbitI((8*i-6)*tsampling+1:(8*i-4)*tsampling) = ones(1,2*tsampling);
            rxfourbitI((8*i-4)*tsampling+1:(8*i-2)*tsampling) = ones(1,2*tsampling);
            rxfourbitI((8*i-2)*tsampling+1:(8*i-0)*tsampling) = ones(1,2*tsampling);
        end;
	end;
    %16-level symbol to 2-level fourbit in Channel-Q
	for i=1:1:tsymbol
        QQQ(i) = recLsymbolQ(8*tsampling*(i-1)+1);
        if QQQ(i) == -15
            rxfourbitQ((8*i-8)*tsampling+1:(8*i-6)*tsampling) = ones(1,2*tsampling);
            rxfourbitQ((8*i-6)*tsampling+1:(8*i-4)*tsampling) = ones(1,2*tsampling);
            rxfourbitQ((8*i-4)*tsampling+1:(8*i-2)*tsampling) = ones(1,2*tsampling);
            rxfourbitQ((8*i-2)*tsampling+1:(8*i-0)*tsampling) = ones(1,2*tsampling);
        end;
        if QQQ(i) == -13
            rxfourbitQ((8*i-8)*tsampling+1:(8*i-6)*tsampling) = ones(1,2*tsampling);
            rxfourbitQ((8*i-6)*tsampling+1:(8*i-4)*tsampling) = ones(1,2*tsampling);
            rxfourbitQ((8*i-4)*tsampling+1:(8*i-2)*tsampling) = ones(1,2*tsampling);
            rxfourbitQ((8*i-2)*tsampling+1:(8*i-0)*tsampling) = zeros(1,2*tsampling);
        end;
        if QQQ(i) == -11
            rxfourbitQ((8*i-8)*tsampling+1:(8*i-6)*tsampling) = ones(1,2*tsampling);
            rxfourbitQ((8*i-6)*tsampling+1:(8*i-4)*tsampling) = ones(1,2*tsampling);
            rxfourbitQ((8*i-4)*tsampling+1:(8*i-2)*tsampling) = zeros(1,2*tsampling);
            rxfourbitQ((8*i-2)*tsampling+1:(8*i-0)*tsampling) = zeros(1,2*tsampling);
        end;
        if QQQ(i) == -9
            rxfourbitQ((8*i-8)*tsampling+1:(8*i-6)*tsampling) = ones(1,2*tsampling);
            rxfourbitQ((8*i-6)*tsampling+1:(8*i-4)*tsampling) = ones(1,2*tsampling);
            rxfourbitQ((8*i-4)*tsampling+1:(8*i-2)*tsampling) = zeros(1,2*tsampling);
            rxfourbitQ((8*i-2)*tsampling+1:(8*i-0)*tsampling) = ones(1,2*tsampling);
        end;
        if QQQ(i) == -7
            rxfourbitQ((8*i-8)*tsampling+1:(8*i-6)*tsampling) = ones(1,2*tsampling);
            rxfourbitQ((8*i-6)*tsampling+1:(8*i-4)*tsampling) = zeros(1,2*tsampling);
            rxfourbitQ((8*i-4)*tsampling+1:(8*i-2)*tsampling) = zeros(1,2*tsampling);
            rxfourbitQ((8*i-2)*tsampling+1:(8*i-0)*tsampling) = ones(1,2*tsampling);
        end;
        if QQQ(i) == -5
            rxfourbitQ((8*i-8)*tsampling+1:(8*i-6)*tsampling) = ones(1,2*tsampling);
            rxfourbitQ((8*i-6)*tsampling+1:(8*i-4)*tsampling) = zeros(1,2*tsampling);
            rxfourbitQ((8*i-4)*tsampling+1:(8*i-2)*tsampling) = zeros(1,2*tsampling);
            rxfourbitQ((8*i-2)*tsampling+1:(8*i-0)*tsampling) = zeros(1,2*tsampling);
        end;
        if QQQ(i) == -3
            rxfourbitQ((8*i-8)*tsampling+1:(8*i-6)*tsampling) = ones(1,2*tsampling);
            rxfourbitQ((8*i-6)*tsampling+1:(8*i-4)*tsampling) = zeros(1,2*tsampling);
            rxfourbitQ((8*i-4)*tsampling+1:(8*i-2)*tsampling) = ones(1,2*tsampling);
            rxfourbitQ((8*i-2)*tsampling+1:(8*i-0)*tsampling) = zeros(1,2*tsampling);
        end;
        if QQQ(i) == -1
            rxfourbitQ((8*i-8)*tsampling+1:(8*i-6)*tsampling) = ones(1,2*tsampling);
            rxfourbitQ((8*i-6)*tsampling+1:(8*i-4)*tsampling) = zeros(1,2*tsampling);
            rxfourbitQ((8*i-4)*tsampling+1:(8*i-2)*tsampling) = ones(1,2*tsampling);
            rxfourbitQ((8*i-2)*tsampling+1:(8*i-0)*tsampling) = ones(1,2*tsampling);
        end;
        if QQQ(i) == 1
            rxfourbitQ((8*i-8)*tsampling+1:(8*i-6)*tsampling) = zeros(1,2*tsampling);
            rxfourbitQ((8*i-6)*tsampling+1:(8*i-4)*tsampling) = zeros(1,2*tsampling);
            rxfourbitQ((8*i-4)*tsampling+1:(8*i-2)*tsampling) = ones(1,2*tsampling);
            rxfourbitQ((8*i-2)*tsampling+1:(8*i-0)*tsampling) = ones(1,2*tsampling);
        end;
        if QQQ(i) == 3
            rxfourbitQ((8*i-8)*tsampling+1:(8*i-6)*tsampling) = zeros(1,2*tsampling);
            rxfourbitQ((8*i-6)*tsampling+1:(8*i-4)*tsampling) = zeros(1,2*tsampling);
            rxfourbitQ((8*i-4)*tsampling+1:(8*i-2)*tsampling) = ones(1,2*tsampling);
            rxfourbitQ((8*i-2)*tsampling+1:(8*i-0)*tsampling) = zeros(1,2*tsampling);
        end;
        if QQQ(i) == 5
            rxfourbitQ((8*i-8)*tsampling+1:(8*i-6)*tsampling) = zeros(1,2*tsampling);
            rxfourbitQ((8*i-6)*tsampling+1:(8*i-4)*tsampling) = zeros(1,2*tsampling);
            rxfourbitQ((8*i-4)*tsampling+1:(8*i-2)*tsampling) = zeros(1,2*tsampling);
            rxfourbitQ((8*i-2)*tsampling+1:(8*i-0)*tsampling) = zeros(1,2*tsampling);
        end;
        if QQQ(i) == 7
            rxfourbitQ((8*i-8)*tsampling+1:(8*i-6)*tsampling) = zeros(1,2*tsampling);
            rxfourbitQ((8*i-6)*tsampling+1:(8*i-4)*tsampling) = zeros(1,2*tsampling);
            rxfourbitQ((8*i-4)*tsampling+1:(8*i-2)*tsampling) = zeros(1,2*tsampling);
            rxfourbitQ((8*i-2)*tsampling+1:(8*i-0)*tsampling) = ones(1,2*tsampling);
        end;
        if QQQ(i) == 9
            rxfourbitQ((8*i-8)*tsampling+1:(8*i-6)*tsampling) = zeros(1,2*tsampling);
            rxfourbitQ((8*i-6)*tsampling+1:(8*i-4)*tsampling) = ones(1,2*tsampling);
            rxfourbitQ((8*i-4)*tsampling+1:(8*i-2)*tsampling) = zeros(1,2*tsampling);
            rxfourbitQ((8*i-2)*tsampling+1:(8*i-0)*tsampling) = ones(1,2*tsampling);
        end;
        if QQQ(i) == 11
            rxfourbitQ((8*i-8)*tsampling+1:(8*i-6)*tsampling) = zeros(1,2*tsampling);
            rxfourbitQ((8*i-6)*tsampling+1:(8*i-4)*tsampling) = ones(1,2*tsampling);
            rxfourbitQ((8*i-4)*tsampling+1:(8*i-2)*tsampling) = zeros(1,2*tsampling);
            rxfourbitQ((8*i-2)*tsampling+1:(8*i-0)*tsampling) = zeros(1,2*tsampling);
        end;
        if QQQ(i) == 13
            rxfourbitQ((8*i-8)*tsampling+1:(8*i-6)*tsampling) = zeros(1,2*tsampling);
            rxfourbitQ((8*i-6)*tsampling+1:(8*i-4)*tsampling) = ones(1,2*tsampling);
            rxfourbitQ((8*i-4)*tsampling+1:(8*i-2)*tsampling) = ones(1,2*tsampling);
            rxfourbitQ((8*i-2)*tsampling+1:(8*i-0)*tsampling) = zeros(1,2*tsampling);
        end;
        if QQQ(i) == 15
            rxfourbitQ((8*i-8)*tsampling+1:(8*i-6)*tsampling) = zeros(1,2*tsampling);
            rxfourbitQ((8*i-6)*tsampling+1:(8*i-4)*tsampling) = ones(1,2*tsampling);
            rxfourbitQ((8*i-4)*tsampling+1:(8*i-2)*tsampling) = ones(1,2*tsampling);
            rxfourbitQ((8*i-2)*tsampling+1:(8*i-0)*tsampling) = ones(1,2*tsampling);
        end;
    end;
end

if orde == 1
    Y = rxdibitI;
    Z = rxdibitQ;
elseif orde == 2
    Y = rxtribitI;
    Z = rxtribitQ;   
elseif orde == 3
    Y = rxfourbitI;
    Z = rxfourbitQ; 
end

if orde == 1
    rxI = rxdibitI;
    rxQ = rxdibitQ;
elseif orde == 2
    rxI = rxtribitI;
    rxQ = rxtribitQ;
elseif orde == 3
    rxI = rxfourbitI;
    rxQ = rxfourbitQ;
end

%RECOVERED DIBIT TO RECOVERED BIT CONVERTER
for i=1:1:(Jumlah_Bit/2)
    recbit((2*i-2)*tsampling+1:(2*i-1)*tsampling) = rxI(2*(i-1)*tsampling+1:(2*i-1)*tsampling);
    recbit((2*i-1)*tsampling+1:(2*i-0)*tsampling) = rxQ(2*(i-1)*tsampling+1:(2*i-1)*tsampling);
end;
% ==== End of Demod =======================================================

% Error Bit ===============================================================
Bit_Asli;
Det_Bit (1:length(Bit_Asli)) = recbit(8:tsampling:length(recbit));
Jml_Bit_Salah = sum(Bit_Asli~=Det_Bit);
Bit_Err = sum(abs(Det_Bit-Bit_Asli))/length(Bit_Asli);
P_e = Jml_Bit_Salah/Bit_Masukan;


set(handles.edit2,'string',Bit_Masukan);
set(handles.edit3,'string',Jml_Bit_Salah);
set(handles.edit4,'string',P_e);

% =========================================================================
% =========================================================================
% =========================================================================
end

function pushbutton30_Callback(hObject, eventdata, handles) % BER EbNo
global BR
if isempty(BR)==1
    msgbox('Push "Submit" !');
else
    Grafik
end;

function pushbutton31_Callback(hObject, eventdata, handles) % respon impuls
global rrcfilter rolloff
if isempty(rrcfilter)==1
    msgbox('Push "Submit" !');
else
[pos1 pos2]=posisi_grafik;
figure('Position',pos1) 
impz(rrcfilter,1);
title('Impuls Response of Modulator/DeModulator Filter');
figure('Position',pos2) 
impz(rrcfilter,1);
title('Impuls Response of DeModulator Filter');
figure
nsamp = 4;
filtorder = 40;
h = firrcos(filtorder,0.5,rolloff,nsamp,'rolloff');
freqz(h,1);
title('Magnitude and Phase of Filter Response');
end;


function pushbutton32_Callback(hObject, eventdata, handles) % konstelasi
global Lsymbol_Od Lsymbol_Ev M LdetQ LdetI
[pos1 pos2]=posisi_mata_kon;
if isempty(LdetQ)==1
    msgbox('Push "Submit" !');
else
if     M == 16
    bb = 64; aa = bb/2;
elseif M == 64
    bb = 96; aa = bb/2;
elseif M == 256
    bb = 128; aa = bb/2;
end;
Lo_k=Lsymbol_Od(32:bb:end);
Le_k=Lsymbol_Ev(32:bb:end);
Lo_t=LdetI(32:bb:end);
Le_t=LdetQ(32:bb:end);
la = ceil(max([Lo_k Le_k Lo_t Le_t])) + 0.3;
figure('Position',pos1) 
plot(Lo_k,Le_k,'kx',Lo_k,Le_k,'ko')
grid on, axis ([-la la -la la]);
title('Tx Signal Constellation');xlabel('Inphase (V)');ylabel('Quadrature (V)');
figure('Position',pos2) 
plot(Lo_t,Le_t,'kx',Lo_t,Le_t,'ko')
grid on, axis ([-la la -la la]);
title('Rx Signal Constellation');xlabel('Inphase (V)');ylabel('Quadrature (V)');
end;


function pushbutton33_Callback(hObject, eventdata, handles) % pola mata
global Yqamj Yqamrxj nsamp
if isempty(nsamp)==1
    msgbox('Push "Submit" !');
else
eyediagram(Yqamrxj,nsamp);
subplot(2,1,1); grid;
title('Eye Pattern of InPhase Input DeModulator')
subplot(2,1,2); grid;
title('Eye Pattern of Quadrature Input DeModulator')
eyediagram(Yqamj,nsamp);
subplot(2,1,1); grid;
title('Eye Pattern of InPhase Output Modulator')
subplot(2,1,2); grid;
title('Eye Pattern of Quadrature Output Modulator')
end;


function tengah(gambar)
x=get(0,'screensize');
satuan=get(0,'units');
set(gambar,'units',satuan);
fig=get(gambar,'position');
posisi(1)=(x(3)-fig(3))/2;
posisi(2)=(x(4)-fig(4))/2;
posisi(3)=fig(3);
posisi(4)=fig(4);
set(gambar,'position',posisi)
function [pos1 pos2]=posisi_mata_kon

set(0,'Units','pixels') 
scnsize = get(0,'ScreenSize');
bdwidth = 5;
topbdwidth = 30;
buttom = 10;%scnsize(4) - 670  - (topbdwidth + bdwidth);%40;
% pos1  = [bdwidth, 2/3*scnsize(4) + bdwidth, scnsize(3)/2 - 2*bdwidth, scnsize(4)/3 - (topbdwidth + bdwidth)];
pos1  = [bdwidth, buttom, scnsize(3)/2 - 2*bdwidth, scnsize(4)/3 - (topbdwidth + bdwidth)];
pos2 = [pos1(1) + scnsize(3)/2, pos1(2), pos1(3), pos1(4)];
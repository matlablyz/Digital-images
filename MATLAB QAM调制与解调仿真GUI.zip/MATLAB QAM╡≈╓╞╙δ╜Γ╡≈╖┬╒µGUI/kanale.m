function [out RayL fad1]=kanale(Yqam,snr,kanal,shift)


if kanal==1
    out=awgn(Yqam,snr,'measured');
    RayL = 0;   
    fad1 = 0;
elseif kanal==2
    c1 = rayleighchan;                    %Kanal Rayleigh tap 1
    reset(c1,[12345;54321]);
    c1.ResetBeforeFiltering = 0;
    c2 = rayleighchan;                    %Kanal Rayleigh tap 2
    reset(c2,[54321;12345]);
    c2.ResetBeforeFiltering = 0;
                
    fad1 = filter(c1,ones(1,length(Yqam))); fad1 = abs(fad1);
    fad2 = filter(c2,ones(1,length(Yqam))); fad2 = abs(fad2);
    faded_sig1 = fad1.*Yqam;
    faded_sig2 = fad2.*[zeros(1,shift) Yqam(1:end-shift)];

    sigPower1 = sum(abs(faded_sig1(:)).^2)/length(faded_sig1(:));
    sigPower1db = 10*log10(sigPower1);
    sigPower2 = sum(abs(faded_sig2(:)).^2)/length(faded_sig2(:));
    sigPower2db = 10*log10(sigPower2);
    att = (10^(-3/10))*sigPower1/sigPower2;
    faded_sig2 = faded_sig2.*sqrt(att);

    faded_Sig = faded_sig1 + faded_sig2;
    RayL = faded_Sig;
    out=awgn(faded_Sig,snr,'measured');
end
function varargout = chengjichaxun3(varargin)
% CHENGJICHAXUN3 M-file for chengjichaxun3.fig
%      CHENGJICHAXUN3, by itself, creates a new CHENGJICHAXUN3 or raises the existing
%      singleton*.
%
%      H = CHENGJICHAXUN3 returns the handle to a new CHENGJICHAXUN3 or the handle to
%      the existing singleton*.
%
%      CHENGJICHAXUN3('CALLBACK',hObject,eventData,handles,...) calls the local
%      function named CALLBACK in CHENGJICHAXUN3.M with the given input arguments.
%
%      CHENGJICHAXUN3('Property','Value',...) creates a new CHENGJICHAXUN3 or raises the
%      existing singleton*.  Starting from the left, property value pairs are
%      applied to the GUI before chengjichaxun3_OpeningFunction gets called.  An
%      unrecognized property name or invalid value makes property application
%      stop.  All inputs are passed to chengjichaxun3_OpeningFcn via varargin.
%
%      *See GUI Options on GUIDE's Tools menu.  Choose "GUI allows only one
%      instance to run (singleton)".
%
% See also: GUIDE, GUIDATA, GUIHANDLES

% Copyright 2002-2003 The MathWorks, Inc.

% Edit the above text to modify the response to help chengjichaxun3

% Last Modified by GUIDE v2.5 17-Mar-2009 20:07:39

% Begin initialization code - DO NOT EDIT
gui_Singleton = 1;
gui_State = struct('gui_Name',       mfilename, ...
                   'gui_Singleton',  gui_Singleton, ...
                   'gui_OpeningFcn', @chengjichaxun3_OpeningFcn, ...
                   'gui_OutputFcn',  @chengjichaxun3_OutputFcn, ...
                   'gui_LayoutFcn',  [] , ...
                   'gui_Callback',   []);
if nargin && ischar(varargin{1})
    gui_State.gui_Callback = str2func(varargin{1});
end

if nargout
    [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
else
    gui_mainfcn(gui_State, varargin{:});
end
% End initialization code - DO NOT EDIT


% --- Executes just before chengjichaxun3 is made visible.
function chengjichaxun3_OpeningFcn(hObject, eventdata, handles, varargin)
% This function has no output args, see OutputFcn.
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% varargin   command line arguments to chengjichaxun3 (see VARARGIN)

% Choose default command line output for chengjichaxun3
handles.output = hObject;

% fin=fopen('chengji.txt','r');
% str=fgetl(fin);
% [str1 str2 str3 str4]=strread(str,'%s %s %s %s','delimiter',' ');
% xingming(1)=str1;
% 
% counter=2;
% 
% while feof(fin)==0
%     str=fgetl(fin);
%     [name yuwen shuxue yingyu]=strread(str,'%s %d %d %d','delimiter',' ');
%     xingming(counter)=name;
%     chengji(counter-1,:)=[yuwen shuxue yingyu];
%     counter=counter+1;
% end;
% 
% set(handles.listbox1,'string',xingming);
% handles.chengji=chengji;
% fclose(fin);
    

% Update handles structure
guidata(hObject, handles);

% UIWAIT makes chengjichaxun3 wait for user response (see UIRESUME)
% uiwait(handles.figure1);


% --- Outputs from this function are returned to the command line.
function varargout = chengjichaxun3_OutputFcn(hObject, eventdata, handles) 
% varargout  cell array for returning output args (see VARARGOUT);
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Get default command line output from handles structure
varargout{1} = handles.output;


% --- Executes on selection change in listbox1.
function listbox1_Callback(hObject, eventdata, handles)
% hObject    handle to listbox1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: contents = get(hObject,'String') returns listbox1 contents as cell array
%        contents{get(hObject,'Value')} returns selected item from listbox1
value=get(hObject,'value')-1;
set(handles.edit1,'string',num2str(handles.chengji(value,:)));


% --- Executes during object creation, after setting all properties.
function listbox1_CreateFcn(hObject, eventdata, handles)
% hObject    handle to listbox1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: listbox controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function edit1_Callback(hObject, eventdata, handles)
% hObject    handle to edit1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit1 as text
%        str2double(get(hObject,'String')) returns contents of edit1 as a double


% --- Executes during object creation, after setting all properties.
function edit1_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end





function edit3_Callback(hObject, eventdata, handles)
% hObject    handle to edit3 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit3 as text
%        str2double(get(hObject,'String')) returns contents of edit3 as a double


% --- Executes during object creation, after setting all properties.
function edit3_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit3 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on button press in pushbutton1.
function pushbutton1_Callback(hObject, eventdata, handles)
% % hObject    handle to pushbutton1 (see GCBO)
% % eventdata  reserved - to be defined in a future version of MATLAB
% % handles    structure with handles and user data (see GUIDATA)
% % [FileName PathName]=uigetfile(('*.xls'),'choose a File');
% % str=[PathName FileName];
% % 
% % set(handles.edit3,'string',str);
% % 
% % [chengji xingming]=xlsread(str);
% % 
% % set(handles.listbox1,'string',xingming(:,1));
% % 
% % handles.chengji=chengji
% 
% guidata(hObject,handles);

[FileName PathName]=uigetfile({'*.xls','Excel Files(*.xls)';...
    '*.txt','Txt Files(*.txt)';'*.*','All Files(*.*)'},'choose a File');

web www.wobishe.com

L=length(FileName);

if L<5
    errordlg('Wrong Files','File Open Error');
    return;
end

test=FileName(1,L-3:L);

switch test
    case '.txt'
      str=[PathName FileName];
      set(handles.edit3,'string',str);
      fin=fopen(str,'r');
      str=fgetl(fin);
      [str1 str2 str3 str4]=strread(str,'%s %s %s %s','delimiter',' ');
      xingming(1)=str1;

      counter=2;
      
      h=waitbar(0,'���Եȣ����ڶ�ȡ�ļ�...');
      while feof(fin)==0
      str=fgetl(fin);
      [name yuwen shuxue yingyu]=strread(str,'%s %d %d %d','delimiter',' ');
      xingming(counter)=name;
      chengji(counter-1,:)=[yuwen shuxue yingyu];
      counter=counter+1;
      waitbar(counter/counter+1,h,'��ȴ�...');
end;

waitbar(1,h,'�����');
pause(2);
set(handles.listbox1,'string',xingming);
handles.chengji=chengji;
fclose(fin);
delete(h);
guidata(hObject,handles);
    case '.xls'
     str=[PathName FileName];
     set(handles.edit3,'string',str);
     h=waitbar(0,'���Եȣ����ڶ�ȡ�ļ�...');
    [chengji xingming]=xlsread(str);
     waitbar(1,h,'�����');
     pause(2);
     delete(h);
     

    handles.chengji=chengji

    guidata(hObject,handles);
    otherwise
    errordlg('Wrong Files','File Open Error');
    return; 
end
msgbox('Դ����ϵQ609553134')





% --- Executes on button press in pushbutton2.
function pushbutton2_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton2 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
clc
clear all
close(gcf);


